package com.example

import com.example.calculator.BillItem
import com.example.calculator.CalculatorEngine
import com.example.parser.PaymentNotificationParser
import com.example.parser.PaymentParseResult
import com.example.qr.UpiUriParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPaymentNotificationParser_validFormats() {
        // Case 1: "Rahul sent you ₹500"
        val r1 = PaymentNotificationParser.parse(title = "Rahul sent you ₹500", text = "UPI transaction successful")
        assertTrue(r1 is PaymentParseResult.Success)
        val s1 = r1 as PaymentParseResult.Success
        assertEquals("Rahul", s1.payerName)
        assertEquals(500.0, s1.amount, 0.001)

        // Case 2: "₹500 received from Rahul"
        val r2 = PaymentNotificationParser.parse(title = "PhonePe", text = "₹500 received from Rahul via UPI")
        assertTrue(r2 is PaymentParseResult.Success)
        val s2 = r2 as PaymentParseResult.Success
        assertEquals("Rahul", s2.payerName)
        assertEquals(500.0, s2.amount, 0.001)

        // Case 3: "Payment received: ₹1,500 from Sunita"
        val r3 = PaymentNotificationParser.parse(title = "Payment received: ₹1,500 from Sunita", text = null)
        assertTrue(r3 is PaymentParseResult.Success)
        val s3 = r3 as PaymentParseResult.Success
        assertEquals("Sunita", s3.payerName)
        assertEquals(1500.0, s3.amount, 0.001)

        // Case 4: Indian comma format "Rs 1,00,000 credited from Vikas"
        val r4 = PaymentNotificationParser.parse(title = "Bank Alert", text = "Rs 1,00,000 credited from Vikas on your account")
        assertTrue(r4 is PaymentParseResult.Success)
        val s4 = r4 as PaymentParseResult.Success
        assertEquals("Vikas", s4.payerName)
        assertEquals(100000.0, s4.amount, 0.001)
    }

    @Test
    fun testPaymentNotificationParser_rejections() {
        // Debited notification
        val r1 = PaymentNotificationParser.parse(title = "Bank Alert", text = "Debited with INR 500 for transaction")
        assertTrue(r1 is PaymentParseResult.Ignored)

        // OTP notification
        val r2 = PaymentNotificationParser.parse(title = "Google", text = "OTP is 593821 for your payment")
        assertTrue(r2 is PaymentParseResult.Ignored)

        // Bill payment due
        val r3 = PaymentNotificationParser.parse(title = "Paytm", text = "Electricity bill due of ₹850")
        assertTrue(r3 is PaymentParseResult.Ignored)

        // Payment request
        val r4 = PaymentNotificationParser.parse(title = "PhonePe", text = "Rahul requested ₹300 from you")
        assertTrue(r4 is PaymentParseResult.Ignored)
    }

    @Test
    fun testCalculatorEngine_gstCalculations() {
        // 18% GST on ₹100 exclusive
        val exclusive = CalculatorEngine.calculateGst(100.0, 18.0, isInclusive = false)
        assertEquals(100.0, exclusive.baseAmount, 0.001)
        assertEquals(18.0, exclusive.gstAmount, 0.001)
        assertEquals(118.0, exclusive.totalAmount, 0.001)

        // 18% GST on ₹118 inclusive
        val inclusive = CalculatorEngine.calculateGst(118.0, 18.0, isInclusive = true)
        assertEquals(100.0, inclusive.baseAmount, 0.01)
        assertEquals(18.0, inclusive.gstAmount, 0.01)
        assertEquals(118.0, inclusive.totalAmount, 0.01)
    }

    @Test
    fun testCalculatorEngine_discountAndSplit() {
        val discount = CalculatorEngine.calculateDiscount(500.0, 20.0)
        assertEquals(100.0, discount.discountAmount, 0.001)
        assertEquals(400.0, discount.finalPrice, 0.001)

        val split = CalculatorEngine.calculateSplitBill(totalAmount = 300.0, peopleCount = 3, tipPercent = 10.0, roundUp = false)
        assertEquals(330.0, split.totalWithTip, 0.001)
        assertEquals(110.0, split.amountPerPerson, 0.001)
    }

    @Test
    fun testCalculatorEngine_quickBill() {
        val items = listOf(
            BillItem(name = "Pen", quantity = 5.0, unitPrice = 10.0),
            BillItem(name = "Book", quantity = 2.0, unitPrice = 50.0)
        )
        // subtotal = 50 + 100 = 150
        val bill = CalculatorEngine.calculateQuickBill(items, discountPercent = 10.0, gstPercent = 18.0)
        assertEquals(150.0, bill.subtotal, 0.001)
        assertEquals(15.0, bill.discountAmount, 0.001)
        // discounted = 135, gst = 135 * 0.18 = 24.3, grand total = 159.3
        assertEquals(24.3, bill.gstAmount, 0.001)
        assertEquals(159.3, bill.grandTotal, 0.001)
    }

    @Test
    fun testUpiUriParser() {
        val uri = UpiUriParser.buildUpiUri(
            upiId = "merchant@upi",
            payeeName = "My Shop",
            amount = 150.0,
            note = "Invoice 12"
        )
        assertTrue(uri.startsWith("upi://pay?"))
        val parsed = UpiUriParser.parseUpiUri(uri)
        assertEquals("merchant@upi", parsed?.upiId)
        assertEquals("My Shop", parsed?.payeeName)
        assertEquals(150.0, parsed?.amount ?: 0.0, 0.001)
    }
}
