package com.example.tts

import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val pendingUtterances = mutableListOf<String>()

    private var currentRate = 1.0f
    private var currentLanguage = "en"
    private var currentVolume = 1.0f

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("TextToSpeechManager", "Failed to initialize TTS", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            applyLanguage(currentLanguage)
            tts?.setSpeechRate(currentRate)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {}
            })
            // Process any pending utterances
            synchronized(pendingUtterances) {
                for (text in pendingUtterances) {
                    speakRaw(text, currentVolume)
                }
                pendingUtterances.clear()
            }
        } else {
            Log.e("TextToSpeechManager", "TTS initialization failed with status $status")
        }
    }

    private fun applyLanguage(lang: String) {
        val locale = when (lang.lowercase(Locale.ROOT)) {
            "hi" -> Locale("hi", "IN")
            "en" -> Locale("en", "IN")
            else -> Locale.getDefault()
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to English
            tts?.setLanguage(Locale.US)
        }
    }

    fun speakPayment(
        payerName: String,
        amount: Double,
        language: String = "en",
        speechRate: Float = 1.0f,
        volume: Float = 1.0f
    ) {
        this.currentLanguage = language
        this.currentRate = speechRate
        this.currentVolume = volume

        val amountInt = if (amount % 1.0 == 0.0) amount.toLong().toString() else amount.toString()

        val textToSpeak = when (language.lowercase(Locale.ROOT)) {
            "hi" -> "$payerName से $amountInt रुपये प्राप्त हुए"
            else -> "Payment received from $payerName, $amountInt rupees."
        }

        speakRaw(textToSpeak, volume)
    }

    fun testAnnouncement(language: String = "en", speechRate: Float = 1.0f, volume: Float = 1.0f) {
        this.currentLanguage = language
        this.currentRate = speechRate
        this.currentVolume = volume

        val text = when (language.lowercase(Locale.ROOT)) {
            "hi" -> "साउंड बॉक्स टेस्ट: राहुल से पाँच सौ रुपये प्राप्त हुए"
            else -> "Sound Box test: Payment received from Rahul, 500 rupees."
        }
        speakRaw(text, volume)
    }

    private fun speakRaw(text: String, volume: Float) {
        if (!isInitialized) {
            synchronized(pendingUtterances) {
                pendingUtterances.add(text)
            }
            return
        }

        applyLanguage(currentLanguage)
        tts?.setSpeechRate(currentRate)

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0.1f, 1.0f))
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "SoundBox_${System.currentTimeMillis()}")
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isInitialized = false
    }
}
