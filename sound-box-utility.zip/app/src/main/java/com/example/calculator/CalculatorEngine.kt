package com.example.calculator

import java.util.Locale

data class CalculationHistoryItem(
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class GstResult(
    val baseAmount: Double,
    val gstRate: Double,
    val gstAmount: Double,
    val totalAmount: Double,
    val isInclusive: Boolean
)

data class DiscountResult(
    val originalPrice: Double,
    val discountPercent: Double,
    val discountAmount: Double,
    val finalPrice: Double,
    val totalSavings: Double
)

data class SplitBillResult(
    val totalAmount: Double,
    val peopleCount: Int,
    val tipPercent: Double,
    val totalWithTip: Double,
    val amountPerPerson: Double,
    val roundedAmountPerPerson: Double
)

data class BillItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val quantity: Double,
    val unitPrice: Double
) {
    val lineTotal: Double
        get() = quantity * unitPrice
}

data class QuickBillSummary(
    val items: List<BillItem>,
    val subtotal: Double,
    val discountPercent: Double,
    val discountAmount: Double,
    val gstPercent: Double,
    val gstAmount: Double,
    val grandTotal: Double
)

object CalculatorEngine {

    // Dynamic GST calculation
    // If Inclusive: Total = Input, Base = Input / (1 + Rate/100), GST = Total - Base
    // If Exclusive: Base = Input, GST = Base * (Rate/100), Total = Base + GST
    fun calculateGst(amount: Double, ratePercent: Double, isInclusive: Boolean): GstResult {
        if (amount <= 0 || ratePercent < 0) {
            return GstResult(0.0, ratePercent, 0.0, 0.0, isInclusive)
        }
        return if (isInclusive) {
            val base = amount / (1.0 + (ratePercent / 100.0))
            val gst = amount - base
            GstResult(
                baseAmount = base,
                gstRate = ratePercent,
                gstAmount = gst,
                totalAmount = amount,
                isInclusive = true
            )
        } else {
            val gst = amount * (ratePercent / 100.0)
            val total = amount + gst
            GstResult(
                baseAmount = amount,
                gstRate = ratePercent,
                gstAmount = gst,
                totalAmount = total,
                isInclusive = false
            )
        }
    }

    fun calculateDiscount(originalPrice: Double, discountPercent: Double): DiscountResult {
        if (originalPrice <= 0 || discountPercent < 0) {
            return DiscountResult(0.0, discountPercent, 0.0, 0.0, 0.0)
        }
        val discountAmount = originalPrice * (discountPercent.coerceIn(0.0, 100.0) / 100.0)
        val finalPrice = (originalPrice - discountAmount).coerceAtLeast(0.0)
        return DiscountResult(
            originalPrice = originalPrice,
            discountPercent = discountPercent,
            discountAmount = discountAmount,
            finalPrice = finalPrice,
            totalSavings = discountAmount
        )
    }

    fun calculateSplitBill(
        totalAmount: Double,
        peopleCount: Int,
        tipPercent: Double = 0.0,
        roundUp: Boolean = false
    ): SplitBillResult {
        val count = peopleCount.coerceAtLeast(1)
        val tipAmount = totalAmount * (tipPercent.coerceAtLeast(0.0) / 100.0)
        val totalWithTip = totalAmount + tipAmount
        val rawPerPerson = totalWithTip / count
        val roundedPerPerson = if (roundUp) kotlin.math.ceil(rawPerPerson) else rawPerPerson

        return SplitBillResult(
            totalAmount = totalAmount,
            peopleCount = count,
            tipPercent = tipPercent,
            totalWithTip = totalWithTip,
            amountPerPerson = rawPerPerson,
            roundedAmountPerPerson = roundedPerPerson
        )
    }

    fun calculateQuickBill(
        items: List<BillItem>,
        discountPercent: Double,
        gstPercent: Double
    ): QuickBillSummary {
        val subtotal = items.sumOf { it.lineTotal }
        val discountAmt = subtotal * (discountPercent.coerceIn(0.0, 100.0) / 100.0)
        val discountedSubtotal = subtotal - discountAmt
        val gstAmt = discountedSubtotal * (gstPercent.coerceAtLeast(0.0) / 100.0)
        val grandTotal = discountedSubtotal + gstAmt

        return QuickBillSummary(
            items = items,
            subtotal = subtotal,
            discountPercent = discountPercent,
            discountAmount = discountAmt,
            gstPercent = gstPercent,
            gstAmount = gstAmt,
            grandTotal = grandTotal
        )
    }

    // Standard Math expression evaluator
    fun evaluateStandardMath(expression: String): String {
        return try {
            val sanitized = expression
                .replace("×", "*")
                .replace("÷", "/")
                .trim()
            val result = evalSimpleExpression(sanitized)
            if (result.isNaN() || result.isInfinite()) {
                "Error"
            } else if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                String.format(Locale.US, "%.4f", result).trimEnd('0').trimEnd('.')
            }
        } catch (_: Exception) {
            "Error"
        }
    }

    private fun evalSimpleExpression(expr: String): Double {
        var clean = expr.replace(" ", "")
        if (clean.isEmpty()) return 0.0

        // Handle percentage operations like 100 + 10%
        if (clean.endsWith("%")) {
            val numStr = clean.dropLast(1)
            val num = numStr.toDoubleOrNull() ?: 0.0
            return num / 100.0
        }

        // Tokenize numbers and operators (+, -, *, /)
        val tokens = mutableListOf<String>()
        var currentNumber = StringBuilder()

        var i = 0
        while (i < clean.length) {
            val c = clean[i]
            if (c.isDigit() || c == '.') {
                currentNumber.append(c)
            } else if (c == '-' && (i == 0 || clean[i - 1] in "+-*/")) {
                currentNumber.append(c)
            } else if (c in "+-*/%") {
                if (currentNumber.isNotEmpty()) {
                    tokens.add(currentNumber.toString())
                    currentNumber = StringBuilder()
                }
                tokens.add(c.toString())
            }
            i++
        }
        if (currentNumber.isNotEmpty()) {
            tokens.add(currentNumber.toString())
        }

        if (tokens.isEmpty()) return 0.0

        // Process * and /
        val intermediateTokens = mutableListOf<String>()
        var idx = 0
        while (idx < tokens.size) {
            val token = tokens[idx]
            if (token == "*" || token == "/") {
                val prev = intermediateTokens.removeAt(intermediateTokens.size - 1).toDouble()
                val next = tokens.getOrNull(idx + 1)?.toDoubleOrNull() ?: 1.0
                val res = if (token == "*") prev * next else prev / next
                intermediateTokens.add(res.toString())
                idx += 2
            } else {
                intermediateTokens.add(token)
                idx++
            }
        }

        // Process + and -
        var result = intermediateTokens[0].toDoubleOrNull() ?: 0.0
        var opIdx = 1
        while (opIdx < intermediateTokens.size) {
            val op = intermediateTokens[opIdx]
            val nextVal = intermediateTokens.getOrNull(opIdx + 1)?.toDoubleOrNull() ?: 0.0
            if (op == "+") {
                result += nextVal
            } else if (op == "-") {
                result -= nextVal
            }
            opIdx += 2
        }

        return result
    }
}
