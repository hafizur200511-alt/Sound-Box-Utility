package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.database.PaymentRecordEntity
import com.example.ui.components.PinLockDialog
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ReceiveScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = SoundBoxApplication.instance
            val settings by app.settingsManager.settings.collectAsState()
            val allRecords by app.database.paymentDao().getAllRecords().collectAsState(initial = emptyList())
            val latestPayment by app.database.paymentDao().getLatestAnnouncedPayment().collectAsState(initial = null)

            val coroutineScope = rememberCoroutineScope()

            var currentTab by remember { mutableStateOf("home") }
            var isUnlocked by remember { mutableStateOf(!settings.appLockEnabled) }

            MyApplicationTheme(themeMode = settings.themeMode) {
                // PIN Lock check if enabled
                if (settings.appLockEnabled && !isUnlocked) {
                    PinLockDialog(
                        settings = settings,
                        onSuccess = { isUnlocked = true },
                        onDismiss = {
                            // If dismissed, keep locked or allow basic view
                        },
                        onResetPin = {
                            coroutineScope.launch {
                                app.settingsManager.updateSettings(
                                    settings.copy(
                                        appLockEnabled = false,
                                        appLockPinHash = ""
                                    )
                                )
                                isUnlocked = true
                            }
                        }
                    )
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("soundbox_main_scaffold"),
                    bottomBar = {
                        NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                            NavigationBarItem(
                                selected = currentTab == "home",
                                onClick = { currentTab = "home" },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") },
                                modifier = Modifier.testTag("nav_item_home")
                            )
                            NavigationBarItem(
                                selected = currentTab == "receive",
                                onClick = { currentTab = "receive" },
                                icon = { Icon(Icons.Default.QrCode, contentDescription = "Receive") },
                                label = { Text("Receive") },
                                modifier = Modifier.testTag("nav_item_receive")
                            )
                            NavigationBarItem(
                                selected = currentTab == "calculator",
                                onClick = { currentTab = "calculator" },
                                icon = { Icon(Icons.Default.Calculate, contentDescription = "Calculator") },
                                label = { Text("Calculator") },
                                modifier = Modifier.testTag("nav_item_calculator")
                            )
                            NavigationBarItem(
                                selected = currentTab == "history",
                                onClick = { currentTab = "history" },
                                icon = { Icon(Icons.Default.History, contentDescription = "History") },
                                label = { Text("History") },
                                modifier = Modifier.testTag("nav_item_history")
                            )
                            NavigationBarItem(
                                selected = currentTab == "settings",
                                onClick = { currentTab = "settings" },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                modifier = Modifier.testTag("nav_item_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    when (currentTab) {
                        "home" -> HomeScreen(
                            settings = settings,
                            allRecords = allRecords,
                            latestPayment = latestPayment,
                            onNavigateToTab = { currentTab = it },
                            onAddManualEntry = { amount, note ->
                                coroutineScope.launch(Dispatchers.IO) {
                                    val entry = PaymentRecordEntity(
                                        payerName = note.ifBlank { "Manual Entry" },
                                        amount = amount,
                                        currency = "INR",
                                        sourceAppPackage = "manual",
                                        sourceAppName = "Manual Entry",
                                        rawNotificationText = "Manual cash entry",
                                        timestamp = System.currentTimeMillis(),
                                        status = "MANUAL",
                                        isManual = true,
                                        note = note
                                    )
                                    app.database.paymentDao().insertRecord(entry)
                                }
                            },
                            onToggleSoundBox = { enabled ->
                                coroutineScope.launch {
                                    app.settingsManager.updateSettings(settings.copy(soundBoxEnabled = enabled))
                                }
                            },
                            onUpdateSelectedPackages = { pkgs ->
                                coroutineScope.launch {
                                    app.settingsManager.updateSelectedPackages(pkgs)
                                }
                            },
                            modifier = Modifier.padding(innerPadding)
                        )

                        "receive" -> ReceiveScreen(
                            settings = settings,
                            onSaveUpiDefaults = { upi, name ->
                                coroutineScope.launch {
                                    app.settingsManager.updateSettings(
                                        settings.copy(
                                            defaultUpiId = upi,
                                            payeeName = name
                                        )
                                    )
                                }
                            },
                            onAddSavedUpi = { upi ->
                                coroutineScope.launch { app.settingsManager.addSavedUpi(upi) }
                            },
                            onUpdateSavedUpi = { upi ->
                                coroutineScope.launch { app.settingsManager.updateSavedUpi(upi) }
                            },
                            onDeleteSavedUpi = { id ->
                                coroutineScope.launch { app.settingsManager.deleteSavedUpi(id) }
                            },
                            onSetDefaultUpi = { id ->
                                coroutineScope.launch { app.settingsManager.setDefaultUpi(id) }
                            },
                            modifier = Modifier.padding(innerPadding)
                        )

                        "calculator" -> CalculatorScreen(
                            settings = settings,
                            modifier = Modifier.padding(innerPadding)
                        )

                        "history" -> HistoryScreen(
                            settings = settings,
                            allRecords = allRecords,
                            onDeleteRecord = { id ->
                                coroutineScope.launch(Dispatchers.IO) {
                                    app.database.paymentDao().deleteRecordById(id)
                                }
                            },
                            onClearDayManualEntries = { start, end ->
                                coroutineScope.launch(Dispatchers.IO) {
                                    app.database.paymentDao().clearManualEntriesBetween(start, end)
                                }
                            },
                            onAddManualEntry = { amount, note ->
                                coroutineScope.launch(Dispatchers.IO) {
                                    val entry = PaymentRecordEntity(
                                        payerName = note.ifBlank { "Manual Entry" },
                                        amount = amount,
                                        currency = "INR",
                                        sourceAppPackage = "manual",
                                        sourceAppName = "Manual Entry",
                                        rawNotificationText = "Manual collection entry",
                                        timestamp = System.currentTimeMillis(),
                                        status = "MANUAL",
                                        isManual = true,
                                        note = note
                                    )
                                    app.database.paymentDao().insertRecord(entry)
                                }
                            },
                            modifier = Modifier.padding(innerPadding)
                        )

                        "settings" -> SettingsScreen(
                            settings = settings,
                            onUpdateSettings = { updated ->
                                coroutineScope.launch {
                                    app.settingsManager.updateSettings(updated)
                                }
                            },
                            onClearAllHistory = {
                                coroutineScope.launch(Dispatchers.IO) {
                                    app.database.paymentDao().clearAllRecords()
                                }
                            },
                            onAddSavedUpi = { upi ->
                                coroutineScope.launch { app.settingsManager.addSavedUpi(upi) }
                            },
                            onUpdateSavedUpi = { upi ->
                                coroutineScope.launch { app.settingsManager.updateSavedUpi(upi) }
                            },
                            onDeleteSavedUpi = { id ->
                                coroutineScope.launch { app.settingsManager.deleteSavedUpi(id) }
                            },
                            onSetDefaultUpi = { id ->
                                coroutineScope.launch { app.settingsManager.setDefaultUpi(id) }
                            },
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
