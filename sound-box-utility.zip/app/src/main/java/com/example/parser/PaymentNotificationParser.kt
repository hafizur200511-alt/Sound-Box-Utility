package com.example.parser

import java.text.NumberFormat
import java.util.Locale
import java.util.regex.Pattern

sealed class PaymentParseResult {
    data class Success(
        val payerName: String,
        val amount: Double,
        val currency: String = "INR",
        val formattedAmount: String
    ) : PaymentParseResult()

    data class Ignored(val reason: String) : PaymentParseResult()
}

object PaymentNotificationParser {

    private val REJECTION_KEYWORDS = listOf(
        "debited", "debit", "withdrawn", "sent to", "paid to", "transferred to",
        "otp", "one time password", "verification code", "secret code",
        "request", "requested", "requesting", "due", "overdue", "bill due",
        "cashback", "offer", "discount", "reward", "coupon",
        "failed", "declined", "unsuccessful", "cancelled",
        "reminder", "balance", "available balance", "statement"
    )

    private val CONFIRMED_PAYMENT_KEYWORDS = listOf(
        "received", "credited", "sent you", "paid you", "payment received",
        "received payment", "transferred", "paid", "has sent", "added to your"
    )

    // Regex for matching Indian currency amount: ₹, Rs, Rs., INR with optional commas and decimals
    private val AMOUNT_PATTERN = Pattern.compile(
        """(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(?:₹|rs\.?|inr|rupees)""",
        Pattern.CASE_INSENSITIVE
    )

    // Patterns for extracting payer name
    private val NAME_PATTERNS = listOf(
        // "Rahul sent you ₹500" or "Rahul has sent you ₹500"
        Pattern.compile("""^([a-zA-Z\s.'’]+?)\s+(?:has\s+)?sent\s+you\b""", Pattern.CASE_INSENSITIVE),
        // "Rahul paid you ₹500"
        Pattern.compile("""^([a-zA-Z\s.'’]+?)\s+(?:has\s+)?paid\s+you\b""", Pattern.CASE_INSENSITIVE),
        // "₹500 received from Rahul" or "Payment received: ₹500 from Rahul"
        Pattern.compile("""(?:received|credited|payment\s+(?:received:?\s*)?(?:of\s+)?(?:₹|rs\.?|inr)?\s*[\d,.]+)\s+(?:from|by)\s+([a-zA-Z\s.'’]+?)(?=\s+(?:via|on|using|through|with|ref|for|upi)\b|[.!?,]|$)""", Pattern.CASE_INSENSITIVE),
        // "from Rahul via UPI" or "from Rahul"
        Pattern.compile("""\bfrom\s+([a-zA-Z\s.'’]+?)(?=\s+(?:via|on|using|through|with|ref|for|upi|to)\b|[.!?,]|$)""", Pattern.CASE_INSENSITIVE),
        // "Paid by Rahul"
        Pattern.compile("""\bpaid\s+by\s+([a-zA-Z\s.'’]+?)(?=\s+(?:via|on|using|through)\b|[.!?,]|$)""", Pattern.CASE_INSENSITIVE)
    )

    fun parse(title: String?, text: String?, bigText: String? = null): PaymentParseResult {
        val combined = listOfNotNull(title, text, bigText)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .trim()

        if (combined.isBlank()) {
            return PaymentParseResult.Ignored("Empty notification content")
        }

        val lower = combined.lowercase(Locale.ROOT)

        // Step 1: Reject negative keywords (debits, OTPs, requests, bills, offers)
        for (kw in REJECTION_KEYWORDS) {
            if (lower.contains(kw)) {
                return PaymentParseResult.Ignored("Contains non-credit keyword: '$kw'")
            }
        }

        // Step 2: Ensure presence of recognized payment credit verbs
        val hasPaymentKeyword = CONFIRMED_PAYMENT_KEYWORDS.any { lower.contains(it) }
        if (!hasPaymentKeyword) {
            return PaymentParseResult.Ignored("No recognized payment credit keyword found")
        }

        // Step 3: Extract amount
        val amount = extractAmount(combined) ?: return PaymentParseResult.Ignored("Could not confidently extract amount")
        if (amount <= 0.0) {
            return PaymentParseResult.Ignored("Amount is zero or negative")
        }

        // Step 4: Extract payer name
        val payerName = extractPayerName(title, text, combined) ?: return PaymentParseResult.Ignored("Could not confidently detect payer name")

        val formattedAmount = formatIndianCurrency(amount)

        return PaymentParseResult.Success(
            payerName = payerName,
            amount = amount,
            currency = "INR",
            formattedAmount = formattedAmount
        )
    }

    private fun extractAmount(text: String): Double? {
        val matcher = AMOUNT_PATTERN.matcher(text)
        if (matcher.find()) {
            val group1 = matcher.group(1)
            val group2 = matcher.group(2)
            val rawNumStr = (group1 ?: group2)?.replace(",", "")?.trim()
            return rawNumStr?.toDoubleOrNull()
        }
        return null
    }

    private fun extractPayerName(title: String?, text: String?, combined: String): String? {
        // Try matching in title first (often "Rahul sent you ₹500" or title is payer name)
        if (!title.isNullOrBlank()) {
            val cleanTitle = title.trim()
            for (pattern in NAME_PATTERNS) {
                val m = pattern.matcher(cleanTitle)
                if (m.find()) {
                    val name = cleanName(m.group(1))
                    if (isValidName(name)) return name
                }
            }
            // If title is just a person's name (e.g., "Rahul Sharma") and text is "₹500 received"
            if (isValidPersonNameString(cleanTitle)) {
                return cleanTitle
            }
        }

        // Next try within text and combined string
        for (source in listOfNotNull(text, combined)) {
            for (pattern in NAME_PATTERNS) {
                val m = pattern.matcher(source)
                if (m.find()) {
                    val name = cleanName(m.group(1))
                    if (isValidName(name)) return name
                }
            }
        }

        return null
    }

    private fun cleanName(raw: String?): String {
        if (raw == null) return ""
        var cleaned = raw.trim()
        // Remove common noisy prefixes
        val noisePrefixes = listOf("customer", "user", "mr.", "mrs.", "ms.", "dr.", "shri", "smt")
        for (prefix in noisePrefixes) {
            if (cleaned.lowercase(Locale.ROOT).startsWith("$prefix ")) {
                cleaned = cleaned.substring(prefix.length + 1).trim()
            }
        }
        // Remove extra spaces
        cleaned = cleaned.replace("\\s+".toRegex(), " ")
        return cleaned
    }

    private fun isValidName(name: String): Boolean {
        if (name.length < 2 || name.length > 50) return false
        val lower = name.lowercase(Locale.ROOT)
        val blacklistedWords = setOf(
            "upi", "bank", "account", "wallet", "app", "phonepe", "gpay", "paytm",
            "bhim", "amazon", "payment", "rupees", "inr", "money", "merchant", "store"
        )
        if (blacklistedWords.any { lower == it || lower.startsWith("$it ") || lower.endsWith(" $it") }) {
            return false
        }
        // Should contain mostly letters
        return name.matches("""^[a-zA-Z\s.'’-]+$""".toRegex())
    }

    private fun isValidPersonNameString(str: String): Boolean {
        if (str.length !in 3..40) return false
        val lower = str.lowercase(Locale.ROOT)
        val invalidTokens = setOf(
            "payment", "received", "credited", "debited", "sent", "google pay",
            "phonepe", "paytm", "bhim", "bank", "rupees", "inr", "transaction", "alert"
        )
        if (invalidTokens.any { lower.contains(it) }) return false
        return str.matches("""^[a-zA-Z\s.'’-]+$""".toRegex()) && str.split(" ").none { it.length > 25 }
    }

    fun formatIndianCurrency(amount: Double): String {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        // Format to standard Indian Rupee representation (e.g. ₹1,500 or ₹1,500.50)
        return try {
            val formatted = format.format(amount)
            if (amount % 1.0 == 0.0) {
                // If round integer, format cleanly without decimals like .00 if desired
                "₹" + String.format(Locale("en", "IN"), "%,.0f", amount)
            } else {
                "₹" + String.format(Locale("en", "IN"), "%,.2f", amount)
            }
        } catch (_: Exception) {
            "₹$amount"
        }
    }
}
