package com.example.qr

import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

data class UpiPaymentDetails(
    val upiId: String,
    val payeeName: String,
    val amount: Double? = null,
    val currency: String = "INR",
    val note: String? = null,
    val rawUri: String
)

object UpiUriParser {

    fun buildUpiUri(
        upiId: String,
        payeeName: String,
        amount: Double? = null,
        note: String? = null
    ): String {
        val cleanUpi = upiId.trim()
        val cleanName = payeeName.trim()

        val sb = StringBuilder("upi://pay?")
        sb.append("pa=").append(URLEncoder.encode(cleanUpi, StandardCharsets.UTF_8.name()))
        sb.append("&pn=").append(URLEncoder.encode(cleanName, StandardCharsets.UTF_8.name()))
        sb.append("&cu=INR")

        if (amount != null && amount > 0) {
            val formattedAm = if (amount % 1.0 == 0.0) {
                amount.toInt().toString()
            } else {
                String.format(java.util.Locale.US, "%.2f", amount)
            }
            sb.append("&am=").append(formattedAm)
        }

        if (!note.isNullOrBlank()) {
            sb.append("&tn=").append(URLEncoder.encode(note.trim(), StandardCharsets.UTF_8.name()))
        }

        return sb.toString()
    }

    fun parseUpiUri(uriString: String): UpiPaymentDetails? {
        val trimmed = uriString.trim()
        if (!trimmed.startsWith("upi://", ignoreCase = true)) {
            return null
        }
        return try {
            val queryString = if (trimmed.contains("?")) trimmed.substringAfter("?") else ""
            val queryParams = mutableMapOf<String, String>()
            if (queryString.isNotEmpty()) {
                queryString.split("&").forEach { param ->
                    val parts = param.split("=", limit = 2)
                    if (parts.size == 2) {
                        val key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8.name())
                        val value = URLDecoder.decode(parts[1], StandardCharsets.UTF_8.name())
                        queryParams[key] = value
                    }
                }
            }

            val upiId = queryParams["pa"] ?: ""
            val payeeName = queryParams["pn"] ?: ""
            val amStr = queryParams["am"]
            val amount = amStr?.toDoubleOrNull()
            val cu = queryParams["cu"] ?: "INR"
            val tn = queryParams["tn"]

            if (upiId.isBlank() && payeeName.isBlank()) {
                null
            } else {
                UpiPaymentDetails(
                    upiId = upiId,
                    payeeName = payeeName,
                    amount = amount,
                    currency = cu,
                    note = tn,
                    rawUri = trimmed
                )
            }
        } catch (_: Exception) {
            null
        }
    }
}
