package com.example.qr

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.EnumMap

object QrCodeGenerator {

    fun generateQrBitmap(content: String, size: Int = 600): Bitmap? {
        return try {
            val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
                put(EncodeHintType.CHARACTER_SET, "UTF-8")
                put(EncodeHintType.MARGIN, 1)
                put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H)
            }
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)

            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) Color.parseColor("#0F172A") else Color.WHITE
                }
            }

            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, width, 0, 0, width, height)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun generateShareableQrCard(
        context: Context,
        shopName: String,
        upiId: String,
        amount: Double?,
        qrContent: String
    ): Bitmap? {
        val qrBitmap = generateQrBitmap(qrContent, 600) ?: return null

        val cardWidth = 800
        val cardHeight = 1080
        val bitmap = Bitmap.createBitmap(cardWidth, cardHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, cardWidth.toFloat(), cardHeight.toFloat(), bgPaint)

        // Card surface with rounded corners and border
        val cardPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
            setShadowLayer(16f, 0f, 6f, Color.parseColor("#20000000"))
        }
        val cardRect = RectF(40f, 40f, (cardWidth - 40).toFloat(), (cardHeight - 40).toFloat())
        canvas.drawRoundRect(cardRect, 32f, 32f, cardPaint)

        // Header decorative banner
        val headerPaint = Paint().apply {
            color = Color.parseColor("#0D47A1")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val headerPath = android.graphics.Path().apply {
            addRoundRect(
                RectF(40f, 40f, (cardWidth - 40).toFloat(), 180f),
                floatArrayOf(32f, 32f, 32f, 32f, 0f, 0f, 0f, 0f),
                android.graphics.Path.Direction.CW
            )
        }
        canvas.drawPath(headerPath, headerPaint)

        // Header text
        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("SCAN & PAY WITH ANY UPI APP", cardWidth / 2f, 120f, headerTextPaint)

        // Shop Name
        val shopNamePaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 44f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(shopName.ifBlank { "Sound Box Store" }, cardWidth / 2f, 250f, shopNamePaint)

        // UPI ID
        val upiPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 28f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(upiId, cardWidth / 2f, 295f, upiPaint)

        // Amount if specified
        if (amount != null && amount > 0) {
            val amountPaint = Paint().apply {
                color = Color.parseColor("#059669")
                textSize = 46f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            val amtStr = if (amount % 1.0 == 0.0) "₹%,.0f".format(amount) else "₹%,.2f".format(amount)
            canvas.drawText("Amount: $amtStr", cardWidth / 2f, 360f, amountPaint)
        }

        // Draw QR Code
        val qrTop = if (amount != null && amount > 0) 390f else 340f
        val qrSize = 520
        val qrLeft = (cardWidth - qrSize) / 2f
        val qrDestRect = Rect(qrLeft.toInt(), qrTop.toInt(), (qrLeft + qrSize).toInt(), (qrTop + qrSize).toInt())
        canvas.drawBitmap(qrBitmap, null, qrDestRect, null)

        // Supported Apps Banner
        val footerPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val footerY = qrTop + qrSize + 50f
        canvas.drawText("BHIM • PhonePe • Google Pay • Paytm • Amazon Pay", cardWidth / 2f, footerY, footerPaint)

        val soundBoxBranding = Paint().apply {
            color = Color.parseColor("#0D47A1")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Powered by Sound Box Utility", cardWidth / 2f, footerY + 40f, soundBoxBranding)

        return bitmap
    }

    fun shareQrCard(context: Context, bitmap: Bitmap) {
        val cachePath = File(context.cacheDir, "images")
        cachePath.mkdirs()
        val imageFile = File(cachePath, "soundbox_upi_qr.png")
        FileOutputStream(imageFile).use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
        val contentUri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            imageFile
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Payment QR"))
    }

    fun saveQrCardToGallery(context: Context, bitmap: Bitmap): Boolean {
        return try {
            val filename = "UPI_QR_${System.currentTimeMillis()}.png"
            val outputStream: OutputStream?
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SoundBox")
                }
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                outputStream = imageUri?.let { resolver.openOutputStream(it) }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/SoundBox"
                val file = File(imagesDir)
                if (!file.exists()) file.mkdir()
                val image = File(imagesDir, filename)
                outputStream = FileOutputStream(image)
            }
            outputStream?.use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
