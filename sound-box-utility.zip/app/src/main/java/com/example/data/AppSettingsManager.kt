package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class SavedUpi(
    val id: String = java.util.UUID.randomUUID().toString(),
    val upiId: String,
    val payeeName: String,
    val label: String = "FamPay", // "FamPay", "PhonePe", "Google Pay", "Paytm", "BHIM", "Bank", "Custom"
    val isDefault: Boolean = false
)

val defaultSavedUpis = listOf(
    SavedUpi(id = "1", upiId = "fampay@upi", payeeName = "FamPay Sound Box", label = "FamPay", isDefault = true),
    SavedUpi(id = "2", upiId = "shop@paytm", payeeName = "Shop Counter", label = "Paytm", isDefault = false),
    SavedUpi(id = "3", upiId = "merchant@okaxis", payeeName = "Store Owner", label = "Google Pay", isDefault = false)
)

data class AppSettings(
    val soundBoxEnabled: Boolean = true,
    val selectedAppPackages: Set<String> = defaultAllowedPackages,
    val ttsLanguage: String = "en", // "en", "hi", "system"
    val speechRate: Float = 1.0f,
    val volume: Float = 1.0f,
    val announcementsEnabled: Boolean = true,
    val duplicateProtectionEnabled: Boolean = true,
    val defaultUpiId: String = "fampay@upi",
    val payeeName: String = "FamPay Sound Box",
    val savedUpis: List<SavedUpi> = defaultSavedUpis,
    val amountPresets: List<Double> = listOf(50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0),
    val defaultGstRate: Double = 18.0,
    val splitRoundingEnabled: Boolean = false,
    val appLockEnabled: Boolean = false,
    val appLockPinHash: String = "",
    val lockSettings: Boolean = true,
    val lockHistory: Boolean = false,
    val lockUpiConfig: Boolean = true,
    val securityQuestion: String = "What is your shop name?",
    val securityAnswerHash: String = "",
    val themeMode: String = "SYSTEM" // "SYSTEM", "LIGHT", "DARK"
)

val defaultAllowedPackages = setOf(
    "com.fampay.in",
    "in.fampay.app",
    "com.phonepe.app",
    "com.google.android.apps.nbu.paisa.user",
    "net.one97.paytm",
    "com.paytm.business",
    "in.org.npci.upiapp",
    "in.amazon.mShop.android.shopping",
    "com.dreamplug.androidapp",
    "com.bharatpe.app",
    "com.whatsapp",
    "com.sbi.upi",
    "com.icicibank.pockets",
    "com.axis.mobile",
    "com.msf.kbank.mobile"
)

class AppSettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("soundbox_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val packagesStr = prefs.getString("selected_packages", null)
        val selectedPackages = if (packagesStr != null) {
            packagesStr.split(",").filter { it.isNotBlank() }.toSet()
        } else {
            defaultAllowedPackages
        }

        val presetsStr = prefs.getString("amount_presets", null)
        val presets = if (presetsStr != null) {
            presetsStr.split(",").mapNotNull { it.toDoubleOrNull() }
        } else {
            listOf(50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0)
        }

        val savedUpisStr = prefs.getString("saved_upis_json", null)
        val savedUpis = deserializeSavedUpis(savedUpisStr)

        val defaultUpi = savedUpis.firstOrNull { it.isDefault } ?: savedUpis.firstOrNull()
        val defaultUpiIdVal = prefs.getString("default_upi_id", defaultUpi?.upiId ?: "fampay@upi") ?: "fampay@upi"
        val payeeNameVal = prefs.getString("payee_name", defaultUpi?.payeeName ?: "FamPay Sound Box") ?: "FamPay Sound Box"

        return AppSettings(
            soundBoxEnabled = prefs.getBoolean("sound_box_enabled", true),
            selectedAppPackages = selectedPackages,
            ttsLanguage = prefs.getString("tts_language", "en") ?: "en",
            speechRate = prefs.getFloat("speech_rate", 1.0f),
            volume = prefs.getFloat("volume", 1.0f),
            announcementsEnabled = prefs.getBoolean("announcements_enabled", true),
            duplicateProtectionEnabled = prefs.getBoolean("duplicate_protection_enabled", true),
            defaultUpiId = defaultUpiIdVal,
            payeeName = payeeNameVal,
            savedUpis = savedUpis,
            amountPresets = presets,
            defaultGstRate = prefs.getFloat("default_gst_rate", 18.0f).toDouble(),
            splitRoundingEnabled = prefs.getBoolean("split_rounding_enabled", false),
            appLockEnabled = prefs.getBoolean("app_lock_enabled", false),
            appLockPinHash = prefs.getString("app_lock_pin_hash", "") ?: "",
            lockSettings = prefs.getBoolean("lock_settings", true),
            lockHistory = prefs.getBoolean("lock_history", false),
            lockUpiConfig = prefs.getBoolean("lock_upi_config", true),
            securityQuestion = prefs.getString("security_question", "What is your shop name?") ?: "What is your shop name?",
            securityAnswerHash = prefs.getString("security_answer_hash", "") ?: "",
            themeMode = prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM"
        )
    }

    fun updateSoundBoxEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("sound_box_enabled", enabled).apply()
        _settings.value = _settings.value.copy(soundBoxEnabled = enabled)
    }

    fun updateSelectedPackages(packages: Set<String>) {
        prefs.edit().putString("selected_packages", packages.joinToString(",")).apply()
        _settings.value = _settings.value.copy(selectedAppPackages = packages)
    }

    fun updateTtsSettings(language: String, rate: Float, volume: Float, enabled: Boolean) {
        prefs.edit()
            .putString("tts_language", language)
            .putFloat("speech_rate", rate)
            .putFloat("volume", volume)
            .putBoolean("announcements_enabled", enabled)
            .apply()
        _settings.value = _settings.value.copy(
            ttsLanguage = language,
            speechRate = rate,
            volume = volume,
            announcementsEnabled = enabled
        )
    }

    fun updateDuplicateProtection(enabled: Boolean) {
        prefs.edit().putBoolean("duplicate_protection_enabled", enabled).apply()
        _settings.value = _settings.value.copy(duplicateProtectionEnabled = enabled)
    }

    fun updateUpiDetails(upiId: String, payeeName: String) {
        prefs.edit()
            .putString("default_upi_id", upiId)
            .putString("payee_name", payeeName)
            .apply()
        _settings.value = _settings.value.copy(defaultUpiId = upiId, payeeName = payeeName)
    }

    fun updatePresets(presets: List<Double>) {
        prefs.edit().putString("amount_presets", presets.joinToString(",")).apply()
        _settings.value = _settings.value.copy(amountPresets = presets)
    }

    fun updateCalculatorSettings(defaultGst: Double, splitRounding: Boolean) {
        prefs.edit()
            .putFloat("default_gst_rate", defaultGst.toFloat())
            .putBoolean("split_rounding_enabled", splitRounding)
            .apply()
        _settings.value = _settings.value.copy(
            defaultGstRate = defaultGst,
            splitRoundingEnabled = splitRounding
        )
    }

    fun setAppLockPin(pin: String, question: String, answer: String) {
        val pinHash = hashString(pin)
        val answerHash = hashString(answer.trim().lowercase())
        prefs.edit()
            .putBoolean("app_lock_enabled", true)
            .putString("app_lock_pin_hash", pinHash)
            .putString("security_question", question)
            .putString("security_answer_hash", answerHash)
            .apply()
        _settings.value = _settings.value.copy(
            appLockEnabled = true,
            appLockPinHash = pinHash,
            securityQuestion = question,
            securityAnswerHash = answerHash
        )
    }

    fun disableAppLock() {
        prefs.edit()
            .putBoolean("app_lock_enabled", false)
            .putString("app_lock_pin_hash", "")
            .apply()
        _settings.value = _settings.value.copy(
            appLockEnabled = false,
            appLockPinHash = ""
        )
    }

    fun updateLockToggles(settings: Boolean, history: Boolean, upi: Boolean) {
        prefs.edit()
            .putBoolean("lock_settings", settings)
            .putBoolean("lock_history", history)
            .putBoolean("lock_upi_config", upi)
            .apply()
        _settings.value = _settings.value.copy(
            lockSettings = settings,
            lockHistory = history,
            lockUpiConfig = upi
        )
    }

    fun verifyPin(pin: String): Boolean {
        if (!_settings.value.appLockEnabled || _settings.value.appLockPinHash.isEmpty()) return true
        return hashString(pin) == _settings.value.appLockPinHash
    }

    fun verifySecurityAnswer(answer: String): Boolean {
        if (_settings.value.securityAnswerHash.isEmpty()) return false
        return hashString(answer.trim().lowercase()) == _settings.value.securityAnswerHash
    }

    fun updateThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit()
            .putBoolean("sound_box_enabled", newSettings.soundBoxEnabled)
            .putString("selected_packages", newSettings.selectedAppPackages.joinToString(","))
            .putString("tts_language", newSettings.ttsLanguage)
            .putFloat("speech_rate", newSettings.speechRate)
            .putFloat("volume", newSettings.volume)
            .putBoolean("announcements_enabled", newSettings.announcementsEnabled)
            .putBoolean("duplicate_protection_enabled", newSettings.duplicateProtectionEnabled)
            .putString("default_upi_id", newSettings.defaultUpiId)
            .putString("payee_name", newSettings.payeeName)
            .putString("saved_upis_json", serializeSavedUpis(newSettings.savedUpis))
            .putString("amount_presets", newSettings.amountPresets.joinToString(","))
            .putFloat("default_gst_rate", newSettings.defaultGstRate.toFloat())
            .putBoolean("split_rounding_enabled", newSettings.splitRoundingEnabled)
            .putBoolean("app_lock_enabled", newSettings.appLockEnabled)
            .putString("app_lock_pin_hash", newSettings.appLockPinHash)
            .putBoolean("lock_settings", newSettings.lockSettings)
            .putBoolean("lock_history", newSettings.lockHistory)
            .putBoolean("lock_upi_config", newSettings.lockUpiConfig)
            .putString("security_question", newSettings.securityQuestion)
            .putString("security_answer_hash", newSettings.securityAnswerHash)
            .putString("theme_mode", newSettings.themeMode)
            .apply()
        _settings.value = newSettings
    }

    fun addSavedUpi(newUpi: SavedUpi) {
        val currentList = _settings.value.savedUpis.toMutableList()
        val listWithDefaults = if (newUpi.isDefault) {
            currentList.map { it.copy(isDefault = false) }.toMutableList()
        } else {
            currentList
        }
        listWithDefaults.add(newUpi)
        val updatedDefaultUpi = listWithDefaults.firstOrNull { it.isDefault } ?: listWithDefaults.firstOrNull()
        updateSettings(
            _settings.value.copy(
                savedUpis = listWithDefaults,
                defaultUpiId = updatedDefaultUpi?.upiId ?: _settings.value.defaultUpiId,
                payeeName = updatedDefaultUpi?.payeeName ?: _settings.value.payeeName
            )
        )
    }

    fun updateSavedUpi(updatedUpi: SavedUpi) {
        val currentList = _settings.value.savedUpis.map {
            if (it.id == updatedUpi.id) updatedUpi else if (updatedUpi.isDefault) it.copy(isDefault = false) else it
        }
        val updatedDefaultUpi = currentList.firstOrNull { it.isDefault } ?: currentList.firstOrNull()
        updateSettings(
            _settings.value.copy(
                savedUpis = currentList,
                defaultUpiId = updatedDefaultUpi?.upiId ?: _settings.value.defaultUpiId,
                payeeName = updatedDefaultUpi?.payeeName ?: _settings.value.payeeName
            )
        )
    }

    fun deleteSavedUpi(id: String) {
        val currentList = _settings.value.savedUpis.filter { it.id != id }
        val finalList = if (currentList.none { it.isDefault } && currentList.isNotEmpty()) {
            currentList.mapIndexed { idx, item -> if (idx == 0) item.copy(isDefault = true) else item }
        } else {
            currentList
        }
        val defaultItem = finalList.firstOrNull { it.isDefault } ?: finalList.firstOrNull()
        updateSettings(
            _settings.value.copy(
                savedUpis = finalList,
                defaultUpiId = defaultItem?.upiId ?: "fampay@upi",
                payeeName = defaultItem?.payeeName ?: "FamPay Sound Box"
            )
        )
    }

    fun setDefaultUpi(id: String) {
        val currentList = _settings.value.savedUpis.map {
            it.copy(isDefault = (it.id == id))
        }
        val defaultItem = currentList.firstOrNull { it.id == id }
        updateSettings(
            _settings.value.copy(
                savedUpis = currentList,
                defaultUpiId = defaultItem?.upiId ?: _settings.value.defaultUpiId,
                payeeName = defaultItem?.payeeName ?: _settings.value.payeeName
            )
        )
    }

    companion object {
        fun serializeSavedUpis(list: List<SavedUpi>): String {
            val array = JSONArray()
            for (item in list) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("upiId", item.upiId)
                obj.put("payeeName", item.payeeName)
                obj.put("label", item.label)
                obj.put("isDefault", item.isDefault)
                array.put(obj)
            }
            return array.toString()
        }

        fun deserializeSavedUpis(jsonStr: String?): List<SavedUpi> {
            if (jsonStr.isNullOrBlank()) return defaultSavedUpis
            return try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<SavedUpi>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        SavedUpi(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            upiId = obj.getString("upiId"),
                            payeeName = obj.getString("payeeName"),
                            label = obj.optString("label", "FamPay"),
                            isDefault = obj.optBoolean("isDefault", false)
                        )
                    )
                }
                if (list.isEmpty()) defaultSavedUpis else list
            } catch (_: Exception) {
                defaultSavedUpis
            }
        }

        fun hashString(input: String): String {
            val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
