package com.example.service

import android.app.Notification
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.SoundBoxApplication
import com.example.database.PaymentRecordEntity
import com.example.parser.PaymentNotificationParser
import com.example.parser.PaymentParseResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.LinkedHashMap

class PaymentNotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Cache of recent notification signatures with timestamp to prevent duplicates
    private val recentSignatures = Collections.synchronizedMap(
        object : LinkedHashMap<String, Long>(100, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean {
                return size > 200
            }
        }
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: return

        val app = SoundBoxApplication.instance
        val settings = app.settingsManager.settings.value

        // Check if Sound Box is enabled
        if (!settings.soundBoxEnabled) {
            return
        }

        // Check if notification is from one of the user-selected apps
        if (!settings.selectedAppPackages.contains(packageName)) {
            return
        }

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()

        val rawCombined = listOfNotNull(title, text, bigText).joinToString(" | ")

        // Resolve friendly app name
        val pm = packageManager
        val appName = try {
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            packageName
        }

        val now = System.currentTimeMillis()

        // Duplicate check if enabled
        if (settings.duplicateProtectionEnabled) {
            val signature = "${packageName}_${title ?: ""}_${text ?: ""}_${sbn.id}"
            val lastSeen = recentSignatures[signature]
            if (lastSeen != null && (now - lastSeen) < 60_000) {
                Log.d("SoundBoxService", "Duplicate notification ignored: $signature")
                return
            }
            recentSignatures[signature] = now
        }

        // Parse notification
        val parseResult = PaymentNotificationParser.parse(title, text, bigText)

        serviceScope.launch {
            when (parseResult) {
                is PaymentParseResult.Success -> {
                    // Check duplicate amount + payer within 30 seconds
                    val contentSignature = "${packageName}_${parseResult.payerName}_${parseResult.amount}"
                    val lastContentSeen = recentSignatures[contentSignature]
                    if (settings.duplicateProtectionEnabled && lastContentSeen != null && (now - lastContentSeen) < 30_000) {
                        Log.d("SoundBoxService", "Duplicate payment content detected, ignoring: $contentSignature")
                        return@launch
                    }
                    recentSignatures[contentSignature] = now

                    // Record payment in database
                    val record = PaymentRecordEntity(
                        payerName = parseResult.payerName,
                        amount = parseResult.amount,
                        currency = parseResult.currency,
                        sourceAppPackage = packageName,
                        sourceAppName = appName,
                        rawNotificationText = rawCombined,
                        timestamp = now,
                        status = "ANNOUNCED",
                        isManual = false
                    )
                    app.database.paymentDao().insertRecord(record)

                    // Announce via TextToSpeech
                    if (settings.announcementsEnabled) {
                        app.ttsManager.speakPayment(
                            payerName = parseResult.payerName,
                            amount = parseResult.amount,
                            language = settings.ttsLanguage,
                            speechRate = settings.speechRate,
                            volume = settings.volume
                        )
                    }

                    // Haptic feedback
                    triggerHaptic()
                }

                is PaymentParseResult.Ignored -> {
                    Log.d("SoundBoxService", "Notification from $packageName ignored: ${parseResult.reason}")
                }
            }
        }
    }

    private fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 150), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 150), -1)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(200)
                }
            }
        } catch (e: Exception) {
            Log.e("SoundBoxService", "Haptic feedback error", e)
        }
    }
}
