package com.example

import android.app.Application
import com.example.data.AppSettingsManager
import com.example.database.AppDatabase
import com.example.tts.TextToSpeechManager

class SoundBoxApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var settingsManager: AppSettingsManager
        private set

    lateinit var ttsManager: TextToSpeechManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = AppDatabase.getInstance(this)
        settingsManager = AppSettingsManager(this)
        ttsManager = TextToSpeechManager(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        ttsManager.shutdown()
    }

    companion object {
        lateinit var instance: SoundBoxApplication
            private set
    }
}
