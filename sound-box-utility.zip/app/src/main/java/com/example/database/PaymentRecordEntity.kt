package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_records")
data class PaymentRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val payerName: String,
    val amount: Double,
    val currency: String = "INR",
    val sourceAppPackage: String,
    val sourceAppName: String,
    val rawNotificationText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String, // "ANNOUNCED", "IGNORED_LOW_CONFIDENCE", "IGNORED_UNSELECTED_APP", "IGNORED_DUPLICATE"
    val isManual: Boolean = false,
    val note: String = ""
)
