package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payment_records ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<PaymentRecordEntity>>

    @Query("SELECT * FROM payment_records WHERE isManual = 0 ORDER BY timestamp DESC")
    fun getSoundBoxPayments(): Flow<List<PaymentRecordEntity>>

    @Query("SELECT * FROM payment_records WHERE isManual = 1 ORDER BY timestamp DESC")
    fun getManualEntries(): Flow<List<PaymentRecordEntity>>

    @Query("SELECT * FROM payment_records WHERE timestamp >= :startTime AND timestamp <= :endTime ORDER BY timestamp DESC")
    fun getRecordsBetween(startTime: Long, endTime: Long): Flow<List<PaymentRecordEntity>>

    @Query("SELECT * FROM payment_records WHERE status = 'ANNOUNCED' ORDER BY timestamp DESC LIMIT 1")
    fun getLatestAnnouncedPayment(): Flow<PaymentRecordEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: PaymentRecordEntity): Long

    @Query("DELETE FROM payment_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)

    @Query("DELETE FROM payment_records WHERE isManual = 1 AND timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun clearManualEntriesBetween(startTime: Long, endTime: Long)

    @Query("DELETE FROM payment_records")
    suspend fun clearAllRecords()
}
