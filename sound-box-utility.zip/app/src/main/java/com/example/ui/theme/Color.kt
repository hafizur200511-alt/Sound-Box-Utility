package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SoundBoxBlueLight = Color(0xFF1565C0)
val SoundBoxBlueDark = Color(0xFF90CAF9)
val SoundBoxTealLight = Color(0xFF00897B)
val SoundBoxTealDark = Color(0xFF80CBC4)
val SoundBoxAmber = Color(0xFFF57F17)
val SoundBoxGreen = Color(0xFF2E7D32)
val SoundBoxSurfaceLight = Color(0xFFF8FAFC)
val SoundBoxSurfaceDark = Color(0xFF0F172A)
val SoundBoxCardLight = Color(0xFFFFFFFF)
val SoundBoxCardDark = Color(0xFF1E293B)
