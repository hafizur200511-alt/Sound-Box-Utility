package com.example.ui.screens

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.SoundBoxApplication
import com.example.data.AppSettings
import com.example.data.AppSettingsManager
import com.example.ui.components.isNotificationAccessGranted
import com.example.ui.components.openNotificationAccessSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val isKnownPaymentApp: Boolean
)

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit,
    onClearAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = SoundBoxApplication.instance
    var hasNotificationAccess by remember { mutableStateOf(isNotificationAccessGranted(context)) }

    // Dialog states
    var showAppSelectionDialog by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }
    var showResetHistoryDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    // App List for selection
    var installedApps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val knownPaymentPkgs = setOf(
                "com.phonepe.app", "com.google.android.apps.nbu.paisa.user",
                "net.one97.paytm", "in.org.npci.upiapp", "in.amazon.mShop.android.shopping",
                "com.whatsapp", "com.sbi.upi", "com.icicibank.pockets", "com.axis.mobile"
            )
            val list = packages
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 || knownPaymentPkgs.contains(it.packageName) }
                .map { info ->
                    InstalledAppItem(
                        packageName = info.packageName,
                        appName = pm.getApplicationLabel(info).toString(),
                        isKnownPaymentApp = knownPaymentPkgs.contains(info.packageName)
                    )
                }
                .sortedWith(compareByDescending<InstalledAppItem> { it.isKnownPaymentApp }.thenBy { it.appName })
            installedApps = list
        }
    }

    if (showAppSelectionDialog) {
        AppSelectionDialog(
            installedApps = installedApps,
            selectedPackages = settings.selectedAppPackages,
            onDismiss = { showAppSelectionDialog = false },
            onConfirm = { updatedSelection ->
                onUpdateSettings(settings.copy(selectedAppPackages = updatedSelection))
                showAppSelectionDialog = false
            }
        )
    }

    if (showSetPinDialog) {
        SetPinDialog(
            currentQuestion = settings.securityQuestion,
            onDismiss = { showSetPinDialog = false },
            onConfirm = { pin, question, answer ->
                val pinHash = AppSettingsManager.hashString(pin)
                val answerHash = AppSettingsManager.hashString(answer.trim().lowercase())
                onUpdateSettings(
                    settings.copy(
                        appLockEnabled = true,
                        appLockPinHash = pinHash,
                        securityQuestion = question,
                        securityAnswerHash = answerHash
                    )
                )
                showSetPinDialog = false
                Toast.makeText(context, "4-digit PIN Protection Enabled", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showResetHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showResetHistoryDialog = false },
            title = { Text("Clear All Payment History?") },
            text = { Text("This will permanently delete all transaction records and manual collection entries stored locally on this device.") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllHistory()
                        showResetHistoryDialog = false
                        Toast.makeText(context, "All history cleared", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetHistoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy & Local Processing") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("100% Local Guarantee:", fontWeight = FontWeight.Bold)
                    Text("• All notification parsing is performed entirely on your device using local regex algorithms.")
                    Text("• No payment amounts, customer names, or notification logs are ever transmitted to any cloud servers.")
                    Text("• TextToSpeech voice output is produced on-device.")
                    Text("• Transaction history and bill entries are stored exclusively in your local Room database.")
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Got It")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Customize Sound Box, voice announcements, UPI, and security",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Section 1: Sound Box & Notification Access
        item {
            SettingsSectionCard(title = "SOUND BOX CORE", icon = Icons.Default.Notifications) {
                // Sound Box On/Off
                SettingsToggleRow(
                    title = "Sound Box Engine",
                    subtitle = "Listen for payment notifications & announce them aloud",
                    checked = settings.soundBoxEnabled,
                    onCheckedChange = { onUpdateSettings(settings.copy(soundBoxEnabled = it)) },
                    testTag = "toggle_soundbox_engine"
                )

                HorizontalDivider()

                // Notification Access Status
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Android Notification Access", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (hasNotificationAccess) "Access Granted (Ready)" else "Access Required in Android Settings",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (hasNotificationAccess) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            openNotificationAccessSettings(context)
                            hasNotificationAccess = isNotificationAccessGranted(context)
                        },
                        modifier = Modifier.testTag("open_notification_settings_btn")
                    ) {
                        Text(if (hasNotificationAccess) "Check" else "Grant")
                    }
                }

                HorizontalDivider()

                // Allowed Apps Selection
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allowed Notification Apps", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${settings.selectedAppPackages.size} payment apps allowed (All other apps ignored)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { showAppSelectionDialog = true },
                        modifier = Modifier.testTag("select_apps_button")
                    ) {
                        Text("Select")
                    }
                }

                HorizontalDivider()

                // Duplicate Protection
                SettingsToggleRow(
                    title = "Duplicate Protection",
                    subtitle = "Filter repeated notifications and prevent duplicate announcements",
                    checked = settings.duplicateProtectionEnabled,
                    onCheckedChange = { onUpdateSettings(settings.copy(duplicateProtectionEnabled = it)) },
                    testTag = "toggle_duplicate_protection"
                )
            }
        }

        // Section 2: Voice & TextToSpeech Settings
        item {
            SettingsSectionCard(title = "VOICE & ANNOUNCEMENTS", icon = Icons.Default.VolumeUp) {
                // Voice announcements on/off
                SettingsToggleRow(
                    title = "Voice Announcements",
                    subtitle = "Speak incoming payments through the phone speaker",
                    checked = settings.announcementsEnabled,
                    onCheckedChange = { onUpdateSettings(settings.copy(announcementsEnabled = it)) },
                    testTag = "toggle_voice_announcements"
                )

                HorizontalDivider()

                // Language Selection
                Text("Announcement Language:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "en" to "English",
                        "hi" to "Hindi (हिंदी)",
                        "device" to "Device Default"
                    ).forEach { (code, label) ->
                        ElevatedFilterChip(
                            selected = settings.ttsLanguage == code,
                            onClick = { onUpdateSettings(settings.copy(ttsLanguage = code)) },
                            label = { Text(label) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tts_lang_$code")
                        )
                    }
                }

                HorizontalDivider()

                // Speech Rate
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Rate", style = MaterialTheme.typography.bodyMedium)
                        Text("${String.format(java.util.Locale.US, "%.1f", settings.speechRate)}x", fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.speechRate,
                        onValueChange = { onUpdateSettings(settings.copy(speechRate = it)) },
                        valueRange = 0.6f..1.6f,
                        steps = 5,
                        modifier = Modifier.testTag("speech_rate_slider")
                    )
                }

                // Volume
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sound Box Volume", style = MaterialTheme.typography.bodyMedium)
                        Text("${(settings.volume * 100).toInt()}%", fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.volume,
                        onValueChange = { onUpdateSettings(settings.copy(volume = it)) },
                        valueRange = 0.2f..1.0f,
                        modifier = Modifier.testTag("volume_slider")
                    )
                }

                // Test announcement
                Button(
                    onClick = {
                        app.ttsManager.testAnnouncement(
                            language = settings.ttsLanguage,
                            speechRate = settings.speechRate,
                            volume = settings.volume
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_test_speech_button")
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Play Test Announcement")
                }
            }
        }

        // Section 3: Shop & UPI Configuration
        item {
            SettingsSectionCard(title = "SHOP & UPI SETTINGS", icon = Icons.Default.QrCode) {
                var tempUpiId by remember(settings.defaultUpiId) { mutableStateOf(settings.defaultUpiId) }
                var tempPayee by remember(settings.payeeName) { mutableStateOf(settings.payeeName) }

                OutlinedTextField(
                    value = tempUpiId,
                    onValueChange = {
                        tempUpiId = it
                        onUpdateSettings(settings.copy(defaultUpiId = it.trim()))
                    },
                    label = { Text("Default Shop UPI ID (VPA)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_upi_id_input")
                )

                OutlinedTextField(
                    value = tempPayee,
                    onValueChange = {
                        tempPayee = it
                        onUpdateSettings(settings.copy(payeeName = it.trim()))
                    },
                    label = { Text("Default Shop / Payee Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("settings_payee_name_input")
                )
            }
        }

        // Section 4: Security & App Lock
        item {
            SettingsSectionCard(title = "SECURITY & APP LOCK", icon = Icons.Default.Security) {
                SettingsToggleRow(
                    title = "PIN Protection",
                    subtitle = if (settings.appLockEnabled) "App Lock enabled with 4-digit PIN" else "Require 4-digit PIN to access app",
                    checked = settings.appLockEnabled,
                    onCheckedChange = { enabled ->
                        if (enabled) {
                            showSetPinDialog = true
                        } else {
                            onUpdateSettings(settings.copy(appLockEnabled = false))
                        }
                    },
                    testTag = "toggle_app_lock"
                )

                if (settings.appLockEnabled) {
                    OutlinedButton(
                        onClick = { showSetPinDialog = true },
                        modifier = Modifier.fillMaxWidth().testTag("change_pin_btn")
                    ) {
                        Text("Change PIN or Security Question")
                    }
                }
            }
        }

        // Section 5: Theme & Appearance
        item {
            SettingsSectionCard(title = "APPEARANCE", icon = Icons.Default.Palette) {
                Text("Theme Mode:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "SYSTEM" to "System",
                        "LIGHT" to "Light",
                        "DARK" to "Dark"
                    ).forEach { (mode, label) ->
                        ElevatedFilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdateSettings(settings.copy(themeMode = mode)) },
                            label = { Text(label) },
                            modifier = Modifier.weight(1f).testTag("theme_chip_$mode")
                        )
                    }
                }
            }
        }

        // Section 6: Privacy & Data Management
        item {
            SettingsSectionCard(title = "PRIVACY & LOCAL DATA", icon = Icons.Default.PrivacyTip) {
                OutlinedButton(
                    onClick = { showPrivacyDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("privacy_guarantee_btn")
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View 100% Local Privacy Guarantee")
                }

                OutlinedButton(
                    onClick = { showResetHistoryDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().testTag("clear_all_history_btn")
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear All Local History")
                }
            }
        }
    }
}

@Composable
fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            content()
        }
    }
}

@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
fun AppSelectionDialog(
    installedApps: List<InstalledAppItem>,
    selectedPackages: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    var currentSelection by remember { mutableStateOf(selectedPackages.toMutableSet()) }
    var query by remember { mutableStateOf("") }

    val filtered = remember(installedApps, query) {
        if (query.isBlank()) installedApps else installedApps.filter {
            it.appName.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Allowed Payment Apps") },
        text = {
            Column(
                modifier = Modifier.height(360.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Sound Box will announce incoming payments ONLY from checked apps. All other notifications will be ignored.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search installed apps...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filtered.size) { idx ->
                        val item = filtered[idx]
                        val isChecked = currentSelection.contains(item.packageName)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    if (isChecked) currentSelection.remove(item.packageName)
                                    else currentSelection.add(item.packageName)
                                    currentSelection = currentSelection.toMutableSet()
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    if (checked) currentSelection.add(item.packageName)
                                    else currentSelection.remove(item.packageName)
                                    currentSelection = currentSelection.toMutableSet()
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.appName, fontWeight = FontWeight.Medium)
                                    if (item.isKnownPaymentApp) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFE8F5E9)
                                        ) {
                                            Text(
                                                text = "UPI / Payment",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF2E7D32),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Text(item.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(currentSelection) }) {
                Text("Save (${currentSelection.size} Selected)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SetPinDialog(
    currentQuestion: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var question by remember { mutableStateOf(currentQuestion.ifBlank { "What is your shop name?" }) }
    var answer by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set 4-Digit Security PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("4-Digit PIN") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPin = it },
                    label = { Text("Confirm 4-Digit PIN") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text("Security Question (for recovery)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    label = { Text("Security Answer") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (pin.length != 4) {
                    errorMsg = "PIN must be exactly 4 digits"
                } else if (pin != confirmPin) {
                    errorMsg = "PINs do not match"
                } else if (answer.isBlank()) {
                    errorMsg = "Please enter a security answer for PIN recovery"
                } else {
                    onConfirm(pin, question, answer)
                }
            }) {
                Text("Save PIN")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
