package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.BillItem
import com.example.calculator.CalculationHistoryItem
import com.example.calculator.CalculatorEngine
import com.example.data.AppSettings
import com.example.parser.PaymentNotificationParser

@Composable
fun CalculatorScreen(
    settings: AppSettings,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Standard", "GST", "Discount", "Split Bill", "Quick Bill")

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("calculator_screen")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("calculator_tab_$index")
                )
            }
        }

        when (selectedTab) {
            0 -> StandardCalculatorTab()
            1 -> GstCalculatorTab(defaultGst = settings.defaultGstRate)
            2 -> DiscountCalculatorTab()
            3 -> SplitBillTab(defaultRounding = settings.splitRoundingEnabled)
            4 -> QuickBillTab(defaultGst = settings.defaultGstRate)
        }
    }
}

// -------------------------------------------------------------
// TAB 1: STANDARD CALCULATOR WITH HISTORY TAPE
// -------------------------------------------------------------
@Composable
fun StandardCalculatorTab() {
    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("0") }
    var historyList by remember { mutableStateOf(listOf<CalculationHistoryItem>()) }
    var showHistoryDialog by remember { mutableStateOf(false) }

    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = { Text("Calculation History") },
            text = {
                if (historyList.isEmpty()) {
                    Text("No calculations yet.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    LazyColumn(
                        modifier = Modifier.height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(historyList) { item ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = item.expression,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "= ${item.result}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (historyList.isNotEmpty()) {
                    TextButton(onClick = { historyList = emptyList() }) {
                        Text("Clear History")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showHistoryDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Standard Calculator", style = MaterialTheme.typography.labelSmall)
                    IconButton(onClick = { showHistoryDialog = true }, modifier = Modifier.testTag("calc_history_btn")) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                }
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = expression.ifBlank { " " },
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = resultText,
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Keypad Grid
        val buttonRows = listOf(
            listOf("C", "DEL", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("00", "0", ".", "=")
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in buttonRows) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (btn in row) {
                        val isOp = btn in listOf("÷", "×", "-", "+")
                        val isEqual = btn == "="
                        val isClear = btn in listOf("C", "DEL")

                        val btnColor = when {
                            isEqual -> ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            isOp -> ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            isClear -> ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                            else -> ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.surface)
                        }

                        Button(
                            onClick = {
                                when (btn) {
                                    "C" -> {
                                        expression = ""
                                        resultText = "0"
                                    }
                                    "DEL" -> {
                                        if (expression.isNotEmpty()) {
                                            expression = expression.dropLast(1)
                                            resultText = if (expression.isEmpty()) "0" else CalculatorEngine.evaluateStandardMath(expression)
                                        }
                                    }
                                    "=" -> {
                                        if (expression.isNotBlank()) {
                                            val evaluated = CalculatorEngine.evaluateStandardMath(expression)
                                            historyList = listOf(CalculationHistoryItem(expression, evaluated)) + historyList
                                            resultText = evaluated
                                            expression = evaluated
                                        }
                                    }
                                    "%" -> {
                                        expression += "%"
                                        resultText = CalculatorEngine.evaluateStandardMath(expression)
                                    }
                                    else -> {
                                        expression += btn
                                        resultText = CalculatorEngine.evaluateStandardMath(expression)
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("calc_key_$btn"),
                            shape = RoundedCornerShape(16.dp),
                            colors = btnColor
                        ) {
                            if (btn == "DEL") {
                                Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "DEL", modifier = Modifier.size(20.dp))
                            } else {
                                Text(
                                    text = btn,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isEqual) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: GST CALCULATOR (DYNAMIC INCLUSIVE / EXCLUSIVE)
// -------------------------------------------------------------
@Composable
fun GstCalculatorTab(defaultGst: Double) {
    var amountInput by remember { mutableStateOf("") }
    var selectedGstRate by remember { mutableStateOf(defaultGst) }
    var isInclusive by remember { mutableStateOf(false) }

    val amount = amountInput.toDoubleOrNull() ?: 0.0
    val gstResult = remember(amount, selectedGstRate, isInclusive) {
        CalculatorEngine.calculateGst(amount, selectedGstRate, isInclusive)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("GST Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text(if (isInclusive) "Total Amount (Inc. GST)" else "Base Amount (Ex. GST)") },
                    prefix = { Text("₹ ") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gst_amount_input")
                )

                // Inclusive vs Exclusive Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isInclusive) "GST Mode: INCLUSIVE (Reverse Calc)" else "GST Mode: EXCLUSIVE (+GST)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = isInclusive,
                        onCheckedChange = { isInclusive = it },
                        modifier = Modifier.testTag("gst_inclusive_switch")
                    )
                }

                // Standard Rates
                Text("Select GST Rate:", style = MaterialTheme.typography.labelSmall)
                val standardRates = listOf(5.0, 12.0, 18.0, 28.0)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (rate in standardRates) {
                        ElevatedFilterChip(
                            selected = selectedGstRate == rate,
                            onClick = { selectedGstRate = rate },
                            label = { Text("${rate.toInt()}%") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("gst_rate_${rate.toInt()}")
                        )
                    }
                }
            }
        }

        // Calculation Breakdown Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "CALCULATION BREAKDOWN (${selectedGstRate.toInt()}%)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                CalculationRow(
                    label = "Net Base Amount:",
                    value = PaymentNotificationParser.formatIndianCurrency(gstResult.baseAmount)
                )

                CalculationRow(
                    label = "CGST (${selectedGstRate / 2}%):",
                    value = PaymentNotificationParser.formatIndianCurrency(gstResult.gstAmount / 2)
                )

                CalculationRow(
                    label = "SGST (${selectedGstRate / 2}%):",
                    value = PaymentNotificationParser.formatIndianCurrency(gstResult.gstAmount / 2)
                )

                CalculationRow(
                    label = "Total GST Amount:",
                    value = PaymentNotificationParser.formatIndianCurrency(gstResult.gstAmount),
                    isBold = true
                )

                HorizontalDivider()

                CalculationRow(
                    label = "Final Total Amount:",
                    value = PaymentNotificationParser.formatIndianCurrency(gstResult.totalAmount),
                    isHighlight = true
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: DISCOUNT CALCULATOR
// -------------------------------------------------------------
@Composable
fun DiscountCalculatorTab() {
    var originalPriceInput by remember { mutableStateOf("") }
    var discountPercentInput by remember { mutableStateOf("") }

    val originalPrice = originalPriceInput.toDoubleOrNull() ?: 0.0
    val discountPercent = discountPercentInput.toDoubleOrNull() ?: 0.0

    val discountResult = remember(originalPrice, discountPercent) {
        CalculatorEngine.calculateDiscount(originalPrice, discountPercent)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Discount Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = originalPriceInput,
                    onValueChange = { originalPriceInput = it },
                    label = { Text("Original Price (MRP)") },
                    prefix = { Text("₹ ") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("discount_price_input")
                )

                OutlinedTextField(
                    value = discountPercentInput,
                    onValueChange = { discountPercentInput = it },
                    label = { Text("Discount Percentage (%)") },
                    trailingIcon = { Icon(Icons.Default.Percent, contentDescription = "%") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("discount_percent_input")
                )

                // Quick Discount Chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(5.0, 10.0, 20.0, 50.0).forEach { disc ->
                        ElevatedFilterChip(
                            selected = discountPercent == disc,
                            onClick = { discountPercentInput = disc.toInt().toString() },
                            label = { Text("${disc.toInt()}% Off") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Result Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("DISCOUNT SUMMARY", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                CalculationRow(
                    label = "Original Price:",
                    value = PaymentNotificationParser.formatIndianCurrency(discountResult.originalPrice)
                )

                CalculationRow(
                    label = "Total Savings (Discount):",
                    value = "-${PaymentNotificationParser.formatIndianCurrency(discountResult.discountAmount)}",
                    color = Color(0xFF2E7D32)
                )

                HorizontalDivider()

                CalculationRow(
                    label = "Final Price to Pay:",
                    value = PaymentNotificationParser.formatIndianCurrency(discountResult.finalPrice),
                    isHighlight = true
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: SPLIT BILL CALCULATOR
// -------------------------------------------------------------
@Composable
fun SplitBillTab(defaultRounding: Boolean) {
    var totalAmountInput by remember { mutableStateOf("") }
    var peopleInput by remember { mutableStateOf("2") }
    var tipPercentInput by remember { mutableStateOf("0") }
    var roundUp by remember { mutableStateOf(defaultRounding) }

    val totalAmount = totalAmountInput.toDoubleOrNull() ?: 0.0
    val peopleCount = peopleInput.toIntOrNull() ?: 1
    val tipPercent = tipPercentInput.toDoubleOrNull() ?: 0.0

    val splitResult = remember(totalAmount, peopleCount, tipPercent, roundUp) {
        CalculatorEngine.calculateSplitBill(totalAmount, peopleCount, tipPercent, roundUp)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Split Bill Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = totalAmountInput,
                    onValueChange = { totalAmountInput = it },
                    label = { Text("Total Bill Amount") },
                    prefix = { Text("₹ ") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("split_total_input")
                )

                OutlinedTextField(
                    value = peopleInput,
                    onValueChange = { peopleInput = it },
                    label = { Text("Number of People") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("split_people_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Round Up to Nearest Rupee", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = roundUp, onCheckedChange = { roundUp = it })
                }
            }
        }

        // Result Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("EACH PERSON PAYS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(
                    text = PaymentNotificationParser.formatIndianCurrency(
                        if (roundUp) splitResult.roundedAmountPerPerson else splitResult.amountPerPerson
                    ),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Total ${PaymentNotificationParser.formatIndianCurrency(splitResult.totalWithTip)} split between ${splitResult.peopleCount} people",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 5: QUICK BILL CALCULATOR (ITEMIZED SHOP INVOICE)
// -------------------------------------------------------------
@Composable
fun QuickBillTab(defaultGst: Double) {
    val context = LocalContext.current
    var items by remember {
        mutableStateOf(
            listOf(
                BillItem(name = "Item 1", quantity = 1.0, unitPrice = 50.0)
            )
        )
    }
    var discountPercentInput by remember { mutableStateOf("0") }
    var gstPercentInput by remember { mutableStateOf("0") }

    var showAddItemDialog by remember { mutableStateOf(false) }

    val discountPercent = discountPercentInput.toDoubleOrNull() ?: 0.0
    val gstPercent = gstPercentInput.toDoubleOrNull() ?: 0.0

    val billSummary = remember(items, discountPercent, gstPercent) {
        CalculatorEngine.calculateQuickBill(items, discountPercent, gstPercent)
    }

    if (showAddItemDialog) {
        var newItemName by remember { mutableStateOf("") }
        var newQty by remember { mutableStateOf("1") }
        var newPrice by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddItemDialog = false },
            title = { Text("Add Item to Bill") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newItemName,
                        onValueChange = { newItemName = it },
                        label = { Text("Item Name (e.g. Pen, Notebook)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newQty,
                        onValueChange = { newQty = it },
                        label = { Text("Quantity") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPrice,
                        onValueChange = { newPrice = it },
                        label = { Text("Price per Unit (₹)") },
                        prefix = { Text("₹ ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = newQty.toDoubleOrNull() ?: 1.0
                        val price = newPrice.toDoubleOrNull() ?: 0.0
                        if (price > 0) {
                            val name = newItemName.ifBlank { "Item ${items.size + 1}" }
                            items = items + BillItem(name = name, quantity = qty, unitPrice = price)
                            showAddItemDialog = false
                        }
                    }
                ) {
                    Text("Add Item")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddItemDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Quick Bill Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddItemDialog = true },
                modifier = Modifier.testTag("quick_bill_add_item_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Item")
            }
        }

        // Items List Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (items.isEmpty()) {
                    Text(
                        text = "No items added yet. Click 'Add Item' above.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    items.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${item.quantity} × ${PaymentNotificationParser.formatIndianCurrency(item.unitPrice)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = PaymentNotificationParser.formatIndianCurrency(item.lineTotal),
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = {
                                items = items.filterIndexed { i, _ -> i != index }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        if (index < items.size - 1) HorizontalDivider()
                    }
                }
            }
        }

        // Adjustment Controls: Discount & GST
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = discountPercentInput,
                    onValueChange = { discountPercentInput = it },
                    label = { Text("Discount (%)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = gstPercentInput,
                    onValueChange = { gstPercentInput = it },
                    label = { Text("GST (%)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Bill Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("BILL SUMMARY", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                CalculationRow(label = "Subtotal:", value = PaymentNotificationParser.formatIndianCurrency(billSummary.subtotal))
                if (billSummary.discountAmount > 0) {
                    CalculationRow(
                        label = "Discount (${billSummary.discountPercent}%):",
                        value = "-${PaymentNotificationParser.formatIndianCurrency(billSummary.discountAmount)}",
                        color = Color(0xFF2E7D32)
                    )
                }
                if (billSummary.gstAmount > 0) {
                    CalculationRow(
                        label = "GST (${billSummary.gstPercent}%):",
                        value = "+${PaymentNotificationParser.formatIndianCurrency(billSummary.gstAmount)}"
                    )
                }

                HorizontalDivider()

                CalculationRow(
                    label = "Grand Total:",
                    value = PaymentNotificationParser.formatIndianCurrency(billSummary.grandTotal),
                    isHighlight = true
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { items = emptyList() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear Bill")
                    }

                    Button(
                        onClick = {
                            val receiptText = buildString {
                                appendLine("=== SHOP BILL ===")
                                items.forEach {
                                    appendLine("${it.name}: ${it.quantity} x ${it.unitPrice} = ₹${it.lineTotal}")
                                }
                                appendLine("-----------------")
                                appendLine("Subtotal: ₹${billSummary.subtotal}")
                                if (billSummary.discountAmount > 0) appendLine("Discount: -₹${billSummary.discountAmount}")
                                if (billSummary.gstAmount > 0) appendLine("GST: +₹${billSummary.gstAmount}")
                                appendLine("Grand Total: ₹${billSummary.grandTotal}")
                                appendLine("Powered by Sound Box Utility")
                            }
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, receiptText)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Bill Summary"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share Bill")
                    }
                }
            }
        }
    }
}

@Composable
fun CalculationRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    isHighlight: Boolean = false,
    color: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = if (isHighlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = if (isHighlight || isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            style = if (isHighlight) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyMedium,
            fontWeight = if (isHighlight || isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (color != Color.Unspecified) color else if (isHighlight) MaterialTheme.colorScheme.primary else Color.Unspecified
        )
    }
}
