package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSettings
import com.example.parser.PaymentNotificationParser
import com.example.qr.QrCodeGenerator
import com.example.qr.UpiPaymentDetails
import com.example.qr.UpiUriParser

@Composable
fun ReceiveScreen(
    settings: AppSettings,
    onSaveUpiDefaults: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var upiId by remember(settings.defaultUpiId) { mutableStateOf(settings.defaultUpiId) }
    var payeeName by remember(settings.payeeName) { mutableStateOf(settings.payeeName) }
    var amountText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }

    var showScannerDialog by remember { mutableStateOf(false) }
    var scannedDetails by remember { mutableStateOf<UpiPaymentDetails?>(null) }

    val amountDouble = amountText.toDoubleOrNull()

    // Generate UPI URI
    val upiUri = remember(upiId, payeeName, amountDouble, noteText) {
        if (upiId.isNotBlank()) {
            UpiUriParser.buildUpiUri(upiId, payeeName, amountDouble, noteText)
        } else {
            ""
        }
    }

    val qrBitmap = remember(upiUri) {
        if (upiUri.isNotBlank()) {
            QrCodeGenerator.generateQrBitmap(upiUri, 500)
        } else {
            null
        }
    }

    // Camera Permission launcher for QR scanner
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showScannerDialog = true
        } else {
            Toast.makeText(context, "Camera permission required to scan QR codes", Toast.LENGTH_SHORT).show()
        }
    }

    if (showScannerDialog) {
        QrScannerDialog(
            onDismiss = { showScannerDialog = false },
            onCodeScanned = { rawCode ->
                showScannerDialog = false
                val parsed = UpiUriParser.parseUpiUri(rawCode)
                if (parsed != null) {
                    scannedDetails = parsed
                } else {
                    Toast.makeText(context, "Scanned QR does not contain a standard UPI URI", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    if (scannedDetails != null) {
        ScannedResultDialog(
            details = scannedDetails!!,
            onDismiss = { scannedDetails = null },
            onOpenInApp = {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(scannedDetails!!.rawUri))
                    context.startActivity(Intent.createChooser(intent, "Pay using UPI app"))
                } catch (e: Exception) {
                    Toast.makeText(context, "No UPI app found to handle payment", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("receive_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Receive Payment",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Generate instant UPI dynamic/reusable QR code",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(
                onClick = { cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA) },
                modifier = Modifier.testTag("open_qr_scanner_button")
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Scan QR")
            }
        }

        // Important safety disclaimer
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFFFF8E1),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = Color(0xFFF57F17),
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "IMPORTANT: Generating or showing a QR code is NOT proof of payment. Always wait for the Sound Box audio confirmation before delivering goods.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF5D4037),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Input Fields Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("Shop UPI ID (VPA)") },
                    placeholder = { Text("e.g. shop@okaxis, 9876543210@paytm") },
                    singleLine = true,
                    trailingIcon = {
                        if (upiId != settings.defaultUpiId) {
                            TextButton(onClick = { onSaveUpiDefaults(upiId, payeeName) }) {
                                Text("Save Default")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upi_id_input")
                )

                OutlinedTextField(
                    value = payeeName,
                    onValueChange = { payeeName = it },
                    label = { Text("Shop / Payee Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payee_name_input")
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (Optional - leave empty for reusable QR)") },
                    prefix = { Text("₹ ") },
                    trailingIcon = {
                        if (amountText.isNotEmpty()) {
                            IconButton(onClick = { amountText = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear amount")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("receive_amount_input")
                )

                // Amount Presets Row
                Text(
                    text = "Quick Presets:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (preset in settings.amountPresets) {
                        val formattedPreset = if (preset % 1.0 == 0.0) preset.toInt().toString() else preset.toString()
                        ElevatedFilterChip(
                            selected = amountText == formattedPreset,
                            onClick = {
                                amountText = if (amountText == formattedPreset) "" else formattedPreset
                            },
                            label = { Text("₹$formattedPreset") },
                            modifier = Modifier.testTag("preset_chip_$formattedPreset")
                        )
                    }
                }
            }
        }

        // Live Generated QR Display Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("qr_card_view"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "SCAN & PAY WITH ANY UPI APP",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Text(
                    text = payeeName.ifBlank { "My Shop" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = upiId.ifBlank { "Enter a valid UPI ID" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (amountDouble != null && amountDouble > 0) {
                    Text(
                        text = PaymentNotificationParser.formatIndianCurrency(amountDouble),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF2E7D32)
                    )
                } else {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "Customer enters amount on phone",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // QR Code Display
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Payment QR Code",
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text("Enter UPI ID to generate QR", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Text(
                    text = "BHIM • PhonePe • Google Pay • Paytm • Amazon Pay",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Action Buttons: Share QR, Save QR, Open in UPI App
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            if (upiUri.isNotBlank()) {
                                val cardBitmap = QrCodeGenerator.generateShareableQrCard(
                                    context,
                                    payeeName,
                                    upiId,
                                    amountDouble,
                                    upiUri
                                )
                                if (cardBitmap != null) {
                                    QrCodeGenerator.shareQrCard(context, cardBitmap)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_qr_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }

                    OutlinedButton(
                        onClick = {
                            if (upiUri.isNotBlank()) {
                                val cardBitmap = QrCodeGenerator.generateShareableQrCard(
                                    context,
                                    payeeName,
                                    upiId,
                                    amountDouble,
                                    upiUri
                                )
                                if (cardBitmap != null) {
                                    val saved = QrCodeGenerator.saveQrCardToGallery(context, cardBitmap)
                                    if (saved) {
                                        Toast.makeText(context, "QR Card saved to Pictures/SoundBox!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Failed to save QR card", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_qr_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save")
                    }
                }

                // Open in UPI app button
                FilledTonalButton(
                    onClick = {
                        if (upiUri.isNotBlank()) {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(upiUri))
                                context.startActivity(Intent.createChooser(intent, "Open with UPI App"))
                            } catch (e: Exception) {
                                Toast.makeText(context, "No UPI payment app installed on this device", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_in_upi_app_button")
                ) {
                    Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Self-Test Payment with UPI App")
                }
            }
        }
    }
}

@Composable
fun ScannedResultDialog(
    details: UpiPaymentDetails,
    onDismiss: () -> Unit,
    onOpenInApp: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("UPI QR Code Detected") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF8E1),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Notice: Scanning a QR does NOT mean money was received. This only reads the payee details.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF795548),
                        modifier = Modifier.padding(8.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "Payee: ${details.payeeName.ifBlank { "Not specified" }}", fontWeight = FontWeight.Bold)
                Text(text = "UPI ID: ${details.upiId}", style = MaterialTheme.typography.bodyMedium)
                if (details.amount != null && details.amount > 0) {
                    Text(
                        text = "Amount: ${PaymentNotificationParser.formatIndianCurrency(details.amount)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onOpenInApp) {
                Text("Open in UPI App")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
