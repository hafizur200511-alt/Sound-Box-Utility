package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Animated audio waveform equalizer with 5 vertical pill bars.
 * Renders an active hardware listening visualizer when Sound Box is on.
 */
@Composable
fun AnimatedSoundBoxEqualizer(
    modifier: Modifier = Modifier,
    isActive: Boolean = true,
    barCount: Int = 5,
    maxBarHeight: Dp = 24.dp,
    barWidth: Dp = 4.dp,
    activeColor: Color = Color(0xFF00C853),
    inactiveColor: Color = MaterialTheme.colorScheme.outlineVariant
) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")

    // Generate animation phases for each bar
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar1"
    )

    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar2"
    )

    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar3"
    )

    val bar4 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(520, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar4"
    )

    val bar5 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(410, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar5"
    )

    val scales = if (isActive) listOf(bar1, bar2, bar3, bar4, bar5) else listOf(0.15f, 0.15f, 0.15f, 0.15f, 0.15f)

    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val scale = scales.getOrElse(i % scales.size) { 0.3f }
            Box(
                modifier = Modifier
                    .width(barWidth)
                    .height(maxBarHeight * scale)
                    .clip(RoundedCornerShape(barWidth / 2))
                    .background(
                        if (isActive) {
                            Brush.verticalGradient(
                                listOf(
                                    activeColor,
                                    MaterialTheme.colorScheme.primary
                                )
                            )
                        } else {
                            Brush.verticalGradient(
                                listOf(
                                    inactiveColor,
                                    inactiveColor
                                )
                            )
                        }
                    )
            )
        }
    }
}

/**
 * Animated glowing status beacon with an expanding radar ring.
 */
@Composable
fun PulsingBeaconDot(
    modifier: Modifier = Modifier,
    isActive: Boolean = true,
    activeColor: Color = Color(0xFF00C853),
    inactiveColor: Color = Color(0xFFE53935),
    size: Dp = 12.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = modifier.size(size * 2.4f),
        contentAlignment = Alignment.Center
    ) {
        if (isActive) {
            // Expanding wave ring
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val radius = (size.toPx() / 2f) * pulseScale
                drawCircle(
                    color = activeColor.copy(alpha = pulseAlpha),
                    radius = radius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // Center dot
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(if (isActive) activeColor else inactiveColor)
        )
    }
}

/**
 * Laser scan line effect that sweeps across a QR code container.
 */
@Composable
fun AnimatedQrScanLine(
    modifier: Modifier = Modifier,
    laserColor: Color = Color(0xFF00C853)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "qr_laser")
    val sweepProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_sweep"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val yPos = size.height * sweepProgress
        // Draw laser beam with gradient glow
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    laserColor.copy(alpha = 0f),
                    laserColor.copy(alpha = 0.85f),
                    laserColor,
                    laserColor.copy(alpha = 0.85f),
                    laserColor.copy(alpha = 0f)
                )
            ),
            start = Offset(0f, yPos),
            end = Offset(size.width, yPos),
            strokeWidth = 3.dp.toPx()
        )
    }
}
