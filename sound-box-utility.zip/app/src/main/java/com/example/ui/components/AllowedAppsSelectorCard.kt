package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class PaymentAppOption(
    val name: String,
    val packages: List<String>,
    val badgeColor: Color,
    val description: String
)

val POPULAR_PAYMENT_APPS = listOf(
    PaymentAppOption(
        name = "FamPay",
        packages = listOf("com.fampay.in", "in.fampay.app"),
        badgeColor = Color(0xFFFF9800),
        description = "FamPay & FamApp UPI"
    ),
    PaymentAppOption(
        name = "PhonePe",
        packages = listOf("com.phonepe.app"),
        badgeColor = Color(0xFF673AB7),
        description = "PhonePe UPI & Merchant"
    ),
    PaymentAppOption(
        name = "Google Pay",
        packages = listOf("com.google.android.apps.nbu.paisa.user"),
        badgeColor = Color(0xFF1976D2),
        description = "GPay / Tez"
    ),
    PaymentAppOption(
        name = "Paytm",
        packages = listOf("net.one97.paytm", "com.paytm.business"),
        badgeColor = Color(0xFF00B0FF),
        description = "Paytm & Paytm for Business"
    ),
    PaymentAppOption(
        name = "BHIM UPI",
        packages = listOf("in.org.npci.upiapp"),
        badgeColor = Color(0xFF4CAF50),
        description = "Govt NPCI BHIM"
    ),
    PaymentAppOption(
        name = "Amazon Pay",
        packages = listOf("in.amazon.mShop.android.shopping"),
        badgeColor = Color(0xFFFFB300),
        description = "Amazon Shopping & Pay"
    ),
    PaymentAppOption(
        name = "CRED",
        packages = listOf("com.dreamplug.androidapp"),
        badgeColor = Color(0xFF212121),
        description = "CRED UPI & Pay"
    ),
    PaymentAppOption(
        name = "WhatsApp",
        packages = listOf("com.whatsapp"),
        badgeColor = Color(0xFF25D366),
        description = "WhatsApp UPI Payments"
    ),
    PaymentAppOption(
        name = "Bank UPI",
        packages = listOf("com.sbi.upi", "com.icicibank.pockets", "com.axis.mobile", "com.msf.kbank.mobile"),
        badgeColor = Color(0xFF3F51B5),
        description = "SBI, ICICI, Axis, Kotak"
    )
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AllowedAppsSelectorCard(
    selectedPackages: Set<String>,
    onUpdatePackages: (Set<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    val activeCount = POPULAR_PAYMENT_APPS.count { app ->
        app.packages.any { selectedPackages.contains(it) }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("allowed_apps_selector_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Sound Box Notification Reader",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$activeCount of ${POPULAR_PAYMENT_APPS.size} payment apps enabled",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "Chunein ki Sound Box kis-kis payment app ke notifications ko read kare aur announce kare:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Quick App Chips (Always visible - quick toggle)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (app in POPULAR_PAYMENT_APPS) {
                    val isAppActive = app.packages.any { selectedPackages.contains(it) }

                    ElevatedFilterChip(
                        selected = isAppActive,
                        onClick = {
                            val newSet = selectedPackages.toMutableSet()
                            if (isAppActive) {
                                newSet.removeAll(app.packages.toSet())
                            } else {
                                newSet.addAll(app.packages)
                            }
                            onUpdatePackages(newSet)
                        },
                        label = {
                            Text(
                                text = app.name,
                                fontWeight = if (isAppActive) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isAppActive) {
                            {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = app.badgeColor
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.elevatedFilterChipColors(
                            selectedContainerColor = app.badgeColor.copy(alpha = 0.15f),
                            selectedLabelColor = app.badgeColor
                        ),
                        modifier = Modifier.testTag("app_chip_${app.name.lowercase().replace(" ", "_")}")
                    )
                }
            }

            // Expanded detail view with full description & toggles
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                val allPkgs = POPULAR_PAYMENT_APPS.flatMap { it.packages }.toSet()
                                onUpdatePackages(allPkgs)
                            }
                        ) {
                            Text("Select All Apps")
                        }
                        TextButton(
                            onClick = {
                                onUpdatePackages(emptySet())
                            }
                        ) {
                            Text("Deselect All")
                        }
                    }

                    for (app in POPULAR_PAYMENT_APPS) {
                        val isAppActive = app.packages.any { selectedPackages.contains(it) }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isAppActive) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newSet = selectedPackages.toMutableSet()
                                    if (isAppActive) {
                                        newSet.removeAll(app.packages.toSet())
                                    } else {
                                        newSet.addAll(app.packages)
                                    }
                                    onUpdatePackages(newSet)
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = app.badgeColor,
                                        modifier = Modifier.size(12.dp)
                                    ) {}
                                    Column {
                                        Text(
                                            text = app.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = app.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = isAppActive,
                                    onCheckedChange = { checked ->
                                        val newSet = selectedPackages.toMutableSet()
                                        if (checked) {
                                            newSet.addAll(app.packages)
                                        } else {
                                            newSet.removeAll(app.packages.toSet())
                                        }
                                        onUpdatePackages(newSet)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
