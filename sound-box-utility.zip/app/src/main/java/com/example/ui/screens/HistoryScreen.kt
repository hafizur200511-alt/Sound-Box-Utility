package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.SoundBoxApplication
import com.example.data.AppSettings
import com.example.database.PaymentRecordEntity
import com.example.parser.PaymentNotificationParser
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    settings: AppSettings,
    allRecords: List<PaymentRecordEntity>,
    onDeleteRecord: (Long) -> Unit,
    onClearDayManualEntries: (Long, Long) -> Unit,
    onAddManualEntry: (Double, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val app = SoundBoxApplication.instance

    var filterType by remember { mutableStateOf("ALL") } // "ALL", "SOUNDBOX", "MANUAL"
    var searchQuery by remember { mutableStateOf("") }
    var selectedDayOffset by remember { mutableStateOf(0) } // 0 = Today, -1 = Yesterday, etc.

    var showAddManualDialog by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }

    // Compute date boundaries based on day offset
    val calendar = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, selectedDayOffset)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val startOfDay = calendar.timeInMillis
    val endOfDay = startOfDay + 86_400_000L

    val dateFormat = SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault())
    val dateLabel = when (selectedDayOffset) {
        0 -> "Today (${dateFormat.format(Date(startOfDay))})"
        -1 -> "Yesterday (${dateFormat.format(Date(startOfDay))})"
        else -> dateFormat.format(Date(startOfDay))
    }

    // Filter records by day, type, and search query
    val dayRecords = remember(allRecords, startOfDay, endOfDay) {
        allRecords.filter { it.timestamp in startOfDay until endOfDay }
    }

    val filteredRecords = remember(dayRecords, filterType, searchQuery) {
        dayRecords.filter { record ->
            val matchesType = when (filterType) {
                "SOUNDBOX" -> !record.isManual
                "MANUAL" -> record.isManual
                else -> true
            }
            val matchesQuery = if (searchQuery.isBlank()) {
                true
            } else {
                record.payerName.contains(searchQuery, ignoreCase = true) ||
                        record.sourceAppName.contains(searchQuery, ignoreCase = true) ||
                        record.note.contains(searchQuery, ignoreCase = true)
            }
            matchesType && matchesQuery
        }
    }

    val totalCollection = filteredRecords.sumOf { it.amount }
    val verifiedSoundBoxTotal = dayRecords.filter { !it.isManual && it.status == "ANNOUNCED" }.sumOf { it.amount }
    val manualEntriesTotal = dayRecords.filter { it.isManual }.sumOf { it.amount }

    if (showAddManualDialog) {
        AddManualEntryDialog(
            onDismiss = { showAddManualDialog = false },
            onConfirm = { amt, note ->
                onAddManualEntry(amt, note)
                showAddManualDialog = false
            }
        )
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Clear Manual Entries?") },
            text = { Text("Are you sure you want to clear all manual collection entries for $dateLabel? Verified Sound Box payment events will NOT be deleted.") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearDayManualEntries(startOfDay, endOfDay)
                        showClearConfirmDialog = false
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear Manual")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("history_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Payment History",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Sound Box verified payments & daily collection entries",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = { showAddManualDialog = true },
                    modifier = Modifier.testTag("history_add_manual_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Entry")
                }
            }
        }

        // Date Navigator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { selectedDayOffset -= 1 },
                        modifier = Modifier.testTag("prev_day_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Day")
                    }

                    Text(
                        text = dateLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    IconButton(
                        onClick = { if (selectedDayOffset < 0) selectedDayOffset += 1 },
                        enabled = selectedDayOffset < 0,
                        modifier = Modifier.testTag("next_day_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Day")
                    }
                }
            }
        }

        // Day Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTAL FOR SELECTED DAY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (dayRecords.any { it.isManual }) {
                            TextButton(
                                onClick = { showClearConfirmDialog = true },
                                modifier = Modifier.testTag("clear_day_manual_btn")
                            ) {
                                Text("Clear Manual Entries", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }
                    }

                    Text(
                        text = PaymentNotificationParser.formatIndianCurrency(verifiedSoundBoxTotal + manualEntriesTotal),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE8F5E9),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Sound Box Verified", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                Text(PaymentNotificationParser.formatIndianCurrency(verifiedSoundBoxTotal), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE3F2FD),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Manual Entries", style = MaterialTheme.typography.labelSmall, color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                                Text(PaymentNotificationParser.formatIndianCurrency(manualEntriesTotal), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Search & Filter Chips
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by name, note, or app...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_search_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedFilterChip(
                        selected = filterType == "ALL",
                        onClick = { filterType = "ALL" },
                        label = { Text("All (${dayRecords.size})") },
                        modifier = Modifier.testTag("filter_all")
                    )
                    ElevatedFilterChip(
                        selected = filterType == "SOUNDBOX",
                        onClick = { filterType = "SOUNDBOX" },
                        label = { Text("Sound Box (${dayRecords.count { !it.isManual }})") },
                        modifier = Modifier.testTag("filter_soundbox")
                    )
                    ElevatedFilterChip(
                        selected = filterType == "MANUAL",
                        onClick = { filterType = "MANUAL" },
                        label = { Text("Manual (${dayRecords.count { it.isManual }})") },
                        modifier = Modifier.testTag("filter_manual")
                    )
                }
            }
        }

        // Transactions List
        if (filteredRecords.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No records for this date",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Incoming notifications or manual entries will appear here",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredRecords, key = { it.id }) { record ->
                HistoryRecordCard(
                    record = record,
                    onDelete = { onDeleteRecord(record.id) },
                    onReplay = {
                        if (!record.isManual) {
                            app.ttsManager.speakPayment(
                                payerName = record.payerName,
                                amount = record.amount,
                                language = settings.ttsLanguage,
                                speechRate = settings.speechRate,
                                volume = settings.volume
                            )
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HistoryRecordCard(
    record: PaymentRecordEntity,
    onDelete: () -> Unit,
    onReplay: () -> Unit
) {
    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val formattedTime = timeFormat.format(Date(record.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("history_item_${record.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (record.isManual) Color(0xFFE3F2FD) else Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (record.isManual) "M" else "₹",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = if (record.isManual) Color(0xFF1565C0) else Color(0xFF2E7D32)
                        )
                    }

                    Column {
                        Text(
                            text = record.payerName.ifBlank { if (record.isManual) "Manual Collection" else "Customer" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (record.isManual) Color(0xFFE3F2FD) else Color(0xFFE8F5E9)
                            ) {
                                Text(
                                    text = if (record.isManual) "Manual Entry" else "Sound Box: ${record.sourceAppName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (record.isManual) Color(0xFF0D47A1) else Color(0xFF1B5E20),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Text(
                    text = "+${PaymentNotificationParser.formatIndianCurrency(record.amount)}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (record.isManual) Color(0xFF1565C0) else Color(0xFF2E7D32)
                )
            }

            if (record.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Note: ${record.note}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!record.isManual) {
                    TextButton(onClick = onReplay, modifier = Modifier.testTag("replay_voice_${record.id}")) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Replay Voice")
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_record_${record.id}")) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete entry",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
