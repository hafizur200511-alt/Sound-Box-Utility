package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SavedUpi

val PRESET_UPI_LABELS = listOf("FamPay", "PhonePe", "Google Pay", "Paytm", "BHIM", "Bank UPI", "Personal", "Shop")

@Composable
fun ManageSavedUpisDialog(
    savedUpis: List<SavedUpi>,
    onDismiss: () -> Unit,
    onAddUpi: (SavedUpi) -> Unit,
    onUpdateUpi: (SavedUpi) -> Unit,
    onDeleteUpi: (String) -> Unit,
    onSetDefaultUpi: (String) -> Unit
) {
    var showEditDialog by remember { mutableStateOf<SavedUpi?>(null) }
    var showAddNewDialog by remember { mutableStateOf(false) }

    if (showAddNewDialog) {
        EditUpiDialog(
            upi = null,
            onDismiss = { showAddNewDialog = false },
            onSave = {
                onAddUpi(it)
                showAddNewDialog = false
            }
        )
    }

    if (showEditDialog != null) {
        EditUpiDialog(
            upi = showEditDialog,
            onDismiss = { showEditDialog = null },
            onSave = {
                onUpdateUpi(it)
                showEditDialog = null
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Manage Saved UPI IDs", fontWeight = FontWeight.Bold)
                FilledTonalButton(
                    onClick = { showAddNewDialog = true },
                    modifier = Modifier.testTag("add_new_upi_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add New")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("saved_upis_list_dialog"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Select a default UPI ID or add multiple accounts (FamPay, PhonePe, Paytm, Bank) to quickly generate QR codes with 1-click.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(savedUpis, key = { it.id }) { upi ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (upi.isDefault) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                }
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onSetDefaultUpi(upi.id) },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    RadioButton(
                                        selected = upi.isDefault,
                                        onClick = { onSetDefaultUpi(upi.id) }
                                    )
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = upi.label,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (upi.isDefault) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = MaterialTheme.colorScheme.primary
                                                ) {
                                                    Text(
                                                        text = "DEFAULT",
                                                        color = MaterialTheme.colorScheme.onPrimary,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 10.sp,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = upi.upiId,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = upi.payeeName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Row {
                                    IconButton(onClick = { showEditDialog = upi }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit UPI", modifier = Modifier.size(20.dp))
                                    }
                                    if (savedUpis.size > 1) {
                                        IconButton(onClick = { onDeleteUpi(upi.id) }) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete UPI",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
fun EditUpiDialog(
    upi: SavedUpi?,
    onDismiss: () -> Unit,
    onSave: (SavedUpi) -> Unit
) {
    var upiId by remember { mutableStateOf(upi?.upiId ?: "") }
    var payeeName by remember { mutableStateOf(upi?.payeeName ?: "") }
    var label by remember { mutableStateOf(upi?.label ?: "FamPay") }
    var isDefault by remember { mutableStateOf(upi?.isDefault ?: false) }
    var errorText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (upi == null) "Add New UPI ID" else "Edit UPI ID", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Select Category / App:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (presetLabel in listOf("FamPay", "PhonePe", "Google Pay", "Paytm")) {
                        ElevatedFilterChip(
                            selected = label == presetLabel,
                            onClick = {
                                label = presetLabel
                                if (upiId.isEmpty()) {
                                    when (presetLabel) {
                                        "FamPay" -> upiId = "@fampay"
                                        "PhonePe" -> upiId = "@ybl"
                                        "Google Pay" -> upiId = "@okaxis"
                                        "Paytm" -> upiId = "@paytm"
                                    }
                                }
                            },
                            label = { Text(presetLabel) }
                        )
                    }
                }

                OutlinedTextField(
                    value = upiId,
                    onValueChange = {
                        upiId = it.trim()
                        errorText = ""
                    },
                    label = { Text("UPI ID (VPA)") },
                    placeholder = { Text("e.g. 9876543210@fampay, shop@okaxis") },
                    singleLine = true,
                    isError = errorText.isNotEmpty(),
                    supportingText = {
                        if (errorText.isNotEmpty()) {
                            Text(errorText, color = MaterialTheme.colorScheme.error)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_saved_upi_id")
                )

                OutlinedTextField(
                    value = payeeName,
                    onValueChange = { payeeName = it },
                    label = { Text("Shop / Account Holder Name") },
                    placeholder = { Text("e.g. Ramesh General Store") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_saved_payee_name")
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isDefault = !isDefault }
                ) {
                    Checkbox(
                        checked = isDefault,
                        onCheckedChange = { isDefault = it }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Set as Primary / Default UPI")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (upiId.isBlank() || !upiId.contains("@")) {
                        errorText = "Please enter a valid UPI ID (e.g. yourname@fampay)"
                        return@Button
                    }
                    val finalPayee = payeeName.ifBlank { label }
                    val item = upi?.copy(
                        upiId = upiId,
                        payeeName = finalPayee,
                        label = label,
                        isDefault = isDefault
                    ) ?: SavedUpi(
                        upiId = upiId,
                        payeeName = finalPayee,
                        label = label,
                        isDefault = isDefault
                    )
                    onSave(item)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
